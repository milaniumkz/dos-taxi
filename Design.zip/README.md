
  # Design Transportation Apps

  This is a code bundle for Design Transportation Apps. The original project is available at https://www.figma.com/design/fl44Nw6Wv86Nz6V6hkSL4P/Design-Transportation-Apps.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  