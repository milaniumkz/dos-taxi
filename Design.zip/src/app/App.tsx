import { useState } from 'react';

// Passenger Screens
import { OnboardingScreen } from './components/passenger/OnboardingScreen';
import { MapScreen } from './components/passenger/MapScreen';
import { RideBookingScreen } from './components/passenger/RideBookingScreen';
import { ActiveRideScreen } from './components/passenger/ActiveRideScreen';
import { ProfileScreen } from './components/passenger/ProfileScreen';
import { HistoryScreen } from './components/passenger/HistoryScreen';
import { PaymentScreen } from './components/passenger/PaymentScreen';
import { DeliveryScreen } from './components/passenger/DeliveryScreen';
import { IntercityScreen } from './components/passenger/IntercityScreen';
import { ScooterRentalScreen } from './components/passenger/ScooterRentalScreen';
import { ScooterActiveRide } from './components/passenger/ScooterActiveRide';
import { ProfileIcon } from './components/icons/ProfileIcon';
import { HistoryIcon } from './components/icons/HistoryIcon';
import { PaymentIcon } from './components/icons/PaymentIcon';

// Driver Screens
import { DriverDashboard } from './components/driver/DriverDashboard';
import { IncomingOrderScreen } from './components/driver/IncomingOrderScreen';
import { DriverActiveRide } from './components/driver/DriverActiveRide';
import { EarningsScreen } from './components/driver/EarningsScreen';
import { DriverHistoryScreen } from './components/driver/DriverHistoryScreen';
import { DriverProfileScreen } from './components/driver/DriverProfileScreen';

type AppMode = 'selector' | 'passenger' | 'driver';
type PassengerScreen = 'onboarding' | 'map' | 'booking' | 'active' | 'delivery' | 'profile' | 'history' | 'payment' | 'intercity' | 'scooter' | 'scooter-active';
type DriverScreen = 'dashboard' | 'incoming-order' | 'active-ride' | 'earnings' | 'history' | 'profile';

export default function App() {
  const [appMode, setAppMode] = useState<AppMode>('selector');
  const [passengerScreen, setPassengerScreen] = useState<PassengerScreen>('onboarding');
  const [driverScreen, setDriverScreen] = useState<DriverScreen>('dashboard');
  const [activeScooterId, setActiveScooterId] = useState<string>('');

  // App Mode Selector
  if (appMode === 'selector') {
    return (
      <div className="h-screen bg-gradient-to-br from-[#FFD60A] via-[#FFB800] to-[#FFA500] flex items-center justify-center p-6">
        <div className="w-full max-w-md space-y-8">
          {/* Logo */}
          <div className="text-center space-y-6">
            <div className="relative w-32 h-32 mx-auto">
              <div className="absolute inset-0 bg-gradient-to-br from-[#FFD60A] to-[#FFB800] rounded-[36px] shadow-[0_24px_80px_rgba(255,214,10,0.5),_0_12px_32px_rgba(0,0,0,0.25)] animate-[float_3s_ease-in-out_infinite]" />
              <div className="absolute inset-[4px] bg-gradient-to-br from-[#1C1C1E] to-[#2C2C2E] rounded-[32px] flex items-center justify-center">
                <svg className="w-18 h-18" viewBox="0 0 24 24" fill="none">
                  <defs>
                    <linearGradient id="appLogoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#FFD60A" />
                      <stop offset="100%" stopColor="#FFB800" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"
                    fill="url(#appLogoGrad)"
                  />
                </svg>
              </div>
            </div>
            <div>
              <h1 className="text-6xl font-extrabold tracking-tight mb-2" style={{ fontFamily: 'var(--font-display)', textShadow: '0 4px 24px rgba(0,0,0,0.3), 0 2px 8px rgba(0,0,0,0.2)' }}>
                <span className="text-[#1C1C1E]">DOS</span>{' '}
                <span className="text-[#1C1C1E]">Такси</span>
              </h1>
              <p className="text-[#1C1C1E]/80 text-xl font-semibold" style={{ textShadow: '0 2px 8px rgba(0,0,0,0.15)' }}>Премиум платформа перевозок</p>
            </div>
          </div>

          {/* Mode Selection */}
          <div className="space-y-4">
            <button
              onClick={() => setAppMode('passenger')}
              className="w-full p-6 bg-white/95 backdrop-blur-xl rounded-[28px] shadow-[0_20px_60px_rgba(0,0,0,0.2),_0_8px_24px_rgba(0,0,0,0.15)] hover:shadow-[0_24px_80px_rgba(0,0,0,0.25),_0_12px_32px_rgba(0,0,0,0.18)] transition-all hover:scale-105 active:scale-95 group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-[#FFD60A]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative flex items-center gap-4">
                <div className="w-20 h-20 bg-gradient-to-br from-[#FFD60A] to-[#FFB800] rounded-[24px] flex items-center justify-center shadow-[0_8px_32px_rgba(255,214,10,0.4)] group-hover:scale-110 group-hover:shadow-[0_12px_48px_rgba(255,214,10,0.5)] transition-all">
                  <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
                    <defs>
                      <linearGradient id="passengerIcon" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#1C1C1E" />
                        <stop offset="100%" stopColor="#2C2C2E" />
                      </linearGradient>
                    </defs>
                    <path
                      d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"
                      fill="url(#passengerIcon)"
                    />
                  </svg>
                </div>
                <div className="text-left flex-1">
                  <div className="text-2xl font-bold text-[#1C1C1E] mb-1" style={{ fontFamily: 'var(--font-display)' }}>
                    Пассажир
                  </div>
                  <div className="text-[#6E6E73] font-medium">Заказать поездку или доставку</div>
                </div>
                <svg className="w-7 h-7 text-[#1C1C1E] opacity-30 group-hover:opacity-100 group-hover:translate-x-1 transition-all" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </button>

            <button
              onClick={() => setAppMode('driver')}
              className="w-full p-6 bg-white/95 backdrop-blur-xl rounded-[28px] shadow-[0_20px_60px_rgba(0,0,0,0.2),_0_8px_24px_rgba(0,0,0,0.15)] hover:shadow-[0_24px_80px_rgba(0,0,0,0.25),_0_12px_32px_rgba(0,0,0,0.18)] transition-all hover:scale-105 active:scale-95 group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-[#1C1C1E]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative flex items-center gap-4">
                <div className="w-20 h-20 bg-gradient-to-br from-[#1C1C1E] to-[#2C2C2E] rounded-[24px] flex items-center justify-center shadow-[0_8px_32px_rgba(28,28,30,0.5)] group-hover:scale-110 group-hover:shadow-[0_12px_48px_rgba(28,28,30,0.6)] transition-all">
                  <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
                    <defs>
                      <linearGradient id="driverIcon" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#FFD60A" />
                        <stop offset="100%" stopColor="#FFB800" />
                      </linearGradient>
                    </defs>
                    <path
                      d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"
                      fill="url(#driverIcon)"
                    />
                  </svg>
                </div>
                <div className="text-left flex-1">
                  <div className="text-2xl font-bold text-[#1C1C1E] mb-1" style={{ fontFamily: 'var(--font-display)' }}>
                    Водитель
                  </div>
                  <div className="text-[#6E6E73] font-medium">Заработок на перевозках</div>
                </div>
                <svg className="w-7 h-7 text-[#1C1C1E] opacity-30 group-hover:opacity-100 group-hover:translate-x-1 transition-all" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </button>
          </div>

          {/* Info */}
          <div className="text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-xl rounded-full shadow-[0_4px_16px_rgba(0,0,0,0.1)]">
              <div className="w-2 h-2 bg-[#2ECC71] rounded-full animate-pulse" />
              <span className="text-sm font-medium text-[#1C1C1E]">Система активна</span>
            </div>
          </div>

      <style>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-10px);
          }
        }
      `}</style>
        </div>
      </div>
    );
  }

  // Passenger App
  if (appMode === 'passenger') {
    return (
      <div className="relative">
        {/* Back to selector button */}
        {passengerScreen !== 'onboarding' && (
          <button
            onClick={() => setAppMode('selector')}
            className="absolute top-4 right-4 z-50 p-3 bg-white/95 backdrop-blur-xl rounded-full shadow-lg hover:shadow-xl transition-all"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}

        {passengerScreen === 'onboarding' && (
          <OnboardingScreen onComplete={() => setPassengerScreen('map')} />
        )}

        {passengerScreen === 'map' && (
          <div>
            <MapScreen
              onBookRide={() => setPassengerScreen('booking')}
              onOpenDelivery={() => setPassengerScreen('delivery')}
              onOpenIntercity={() => setPassengerScreen('intercity')}
              onOpenScooter={() => setPassengerScreen('scooter')}
            />
            {/* Quick Access Buttons */}
            <div className="absolute bottom-20 left-4 right-4 z-10 flex gap-3">
              <button
                onClick={() => setPassengerScreen('profile')}
                className="flex-1 bg-white/95 backdrop-blur-xl rounded-[20px] p-4 shadow-[0_12px_48px_rgba(0,0,0,0.15),_0_6px_24px_rgba(0,0,0,0.1)] hover:shadow-[0_20px_60px_rgba(0,0,0,0.2),_0_8px_24px_rgba(0,0,0,0.15)] transition-all hover:scale-105 active:scale-95"
              >
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-gradient-to-br from-[#3B82F6] to-[#2563EB] rounded-2xl flex items-center justify-center shadow-[0_4px_16px_rgba(59,130,246,0.4)]">
                    <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="currentColor">
                      <circle cx="12" cy="8" r="4" />
                      <path d="M20 19c0-3.87-3.13-7-7-7H11c-3.87 0-7 3.13-7 7v1h16v-1z" />
                    </svg>
                  </div>
                  <div className="text-xs font-semibold text-[#1C1C1E]">Профиль</div>
                </div>
              </button>
              <button
                onClick={() => setPassengerScreen('history')}
                className="flex-1 bg-white/95 backdrop-blur-xl rounded-[20px] p-4 shadow-[0_12px_48px_rgba(0,0,0,0.15),_0_6px_24px_rgba(0,0,0,0.1)] hover:shadow-[0_20px_60px_rgba(0,0,0,0.2),_0_8px_24px_rgba(0,0,0,0.15)] transition-all hover:scale-105 active:scale-95"
              >
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-2xl flex items-center justify-center shadow-[0_4px_16px_rgba(245,158,11,0.4)]">
                    <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M13 3a9 9 0 0 0-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42A8.954 8.954 0 0 0 13 21a9 9 0 0 0 0-18zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z" />
                    </svg>
                  </div>
                  <div className="text-xs font-semibold text-[#1C1C1E]">История</div>
                </div>
              </button>
              <button
                onClick={() => setPassengerScreen('payment')}
                className="flex-1 bg-white/95 backdrop-blur-xl rounded-[20px] p-4 shadow-[0_12px_48px_rgba(0,0,0,0.15),_0_6px_24px_rgba(0,0,0,0.1)] hover:shadow-[0_20px_60px_rgba(0,0,0,0.2),_0_8px_24px_rgba(0,0,0,0.15)] transition-all hover:scale-105 active:scale-95"
              >
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-gradient-to-br from-[#10B981] to-[#059669] rounded-2xl flex items-center justify-center shadow-[0_4px_16px_rgba(16,185,129,0.4)]">
                    <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="currentColor">
                      <rect x="2" y="5" width="20" height="14" rx="3" />
                      <rect x="2" y="9" width="20" height="3" opacity="0.3" />
                      <rect x="4" y="14" width="6" height="2" rx="1" opacity="0.8" />
                    </svg>
                  </div>
                  <div className="text-xs font-semibold text-[#1C1C1E]">Оплата</div>
                </div>
              </button>
            </div>
          </div>
        )}

        {passengerScreen === 'booking' && (
          <RideBookingScreen
            onConfirm={() => setPassengerScreen('active')}
            onBack={() => setPassengerScreen('map')}
          />
        )}

        {passengerScreen === 'active' && (
          <ActiveRideScreen
            onComplete={() => setPassengerScreen('map')}
            onCancel={() => setPassengerScreen('map')}
          />
        )}

        {passengerScreen === 'delivery' && (
          <DeliveryScreen
            onBack={() => setPassengerScreen('map')}
            onConfirm={() => setPassengerScreen('map')}
          />
        )}

        {passengerScreen === 'profile' && (
          <ProfileScreen onBack={() => setPassengerScreen('map')} />
        )}

        {passengerScreen === 'history' && (
          <HistoryScreen onBack={() => setPassengerScreen('map')} />
        )}

        {passengerScreen === 'payment' && (
          <PaymentScreen onBack={() => setPassengerScreen('map')} />
        )}

        {passengerScreen === 'intercity' && (
          <IntercityScreen
            onBack={() => setPassengerScreen('map')}
            onConfirm={() => setPassengerScreen('map')}
          />
        )}

        {passengerScreen === 'scooter' && (
          <ScooterRentalScreen
            onBack={() => setPassengerScreen('map')}
            onRent={(scooterId) => {
              setActiveScooterId(scooterId);
              setPassengerScreen('scooter-active');
            }}
          />
        )}

        {passengerScreen === 'scooter-active' && (
          <ScooterActiveRide
            scooterId={activeScooterId}
            onEnd={() => setPassengerScreen('map')}
          />
        )}
      </div>
    );
  }

  // Driver App
  if (appMode === 'driver') {
    return (
      <div className="relative">
        {/* Back to selector button */}
        <button
          onClick={() => setAppMode('selector')}
          className="absolute top-4 right-4 z-50 p-3 bg-white/95 backdrop-blur-xl rounded-full shadow-lg hover:shadow-xl transition-all"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {driverScreen === 'dashboard' && (
          <div>
            <DriverDashboard
              onNewOrder={() => setDriverScreen('incoming-order')}
              onOpenEarnings={() => setDriverScreen('earnings')}
              onOpenProfile={() => setDriverScreen('profile')}
            />
            {/* Updated earnings and history buttons in the dashboard */}
            <div className="absolute bottom-4 left-4 right-4 z-10">
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setDriverScreen('earnings')}
                  className="p-4 bg-white rounded-[20px] shadow-lg hover:shadow-xl transition-all hover:scale-105 active:scale-95"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-[#FFD60A] rounded-full flex items-center justify-center">
                      <svg className="w-6 h-6 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div className="text-left">
                      <div className="font-bold">Заработок</div>
                      <div className="text-xs text-[#6E6E73]">Статистика</div>
                    </div>
                  </div>
                </button>

                <button
                  onClick={() => setDriverScreen('history')}
                  className="p-4 bg-white rounded-[20px] shadow-lg hover:shadow-xl transition-all hover:scale-105 active:scale-95"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-[#1C1C1E] rounded-full flex items-center justify-center">
                      <svg className="w-6 h-6 text-[#FFD60A]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div className="text-left">
                      <div className="font-bold">История</div>
                      <div className="text-xs text-[#6E6E73]">Все поездки</div>
                    </div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        )}

        {driverScreen === 'incoming-order' && (
          <IncomingOrderScreen
            onAccept={() => setDriverScreen('active-ride')}
            onDecline={() => setDriverScreen('dashboard')}
          />
        )}

        {driverScreen === 'active-ride' && (
          <DriverActiveRide onComplete={() => setDriverScreen('dashboard')} />
        )}

        {driverScreen === 'earnings' && (
          <EarningsScreen onBack={() => setDriverScreen('dashboard')} />
        )}

        {driverScreen === 'history' && (
          <DriverHistoryScreen onBack={() => setDriverScreen('dashboard')} />
        )}

        {driverScreen === 'profile' && (
          <DriverProfileScreen onBack={() => setDriverScreen('dashboard')} />
        )}
      </div>
    );
  }

  return null;
}