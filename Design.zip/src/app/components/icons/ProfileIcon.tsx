export function ProfileIcon({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none">
      <defs>
        <linearGradient id="profileGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3B82F6" />
          <stop offset="100%" stopColor="#2563EB" />
        </linearGradient>
      </defs>
      <circle cx="12" cy="8" r="4" fill="url(#profileGrad)" />
      <path
        d="M20 19c0-3.87-3.13-7-7-7H11c-3.87 0-7 3.13-7 7v1h16v-1z"
        fill="url(#profileGrad)"
      />
    </svg>
  );
}
