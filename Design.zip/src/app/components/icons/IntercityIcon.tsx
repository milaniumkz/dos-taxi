export function IntercityIcon({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none">
      <defs>
        <linearGradient id="intercityGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#8B5CF6" />
          <stop offset="100%" stopColor="#7C3AED" />
        </linearGradient>
      </defs>
      <path
        d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"
        fill="url(#intercityGrad)"
      />
      <path
        d="M3.5 12h3M17.5 12h3M12 3.5v3M12 17.5v3"
        stroke="url(#intercityGrad)"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </svg>
  );
}
