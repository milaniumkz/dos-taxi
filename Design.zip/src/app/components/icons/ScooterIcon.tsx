export function ScooterIcon({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none">
      <defs>
        <linearGradient id="scooterGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#2ECC71" />
          <stop offset="100%" stopColor="#27AE60" />
        </linearGradient>
      </defs>
      <circle cx="5" cy="19" r="2" fill="url(#scooterGrad)" />
      <circle cx="19" cy="19" r="2" fill="url(#scooterGrad)" />
      <path
        d="M15 4.5L14 3h-4l-1 1.5L7 5v6h2V8l4 1v2l2-1V5l-0.5-0.5z"
        fill="url(#scooterGrad)"
      />
      <path
        d="M10 11l-3 8h2l2-5 2 5h2l-3-8z"
        fill="url(#scooterGrad)"
      />
    </svg>
  );
}
