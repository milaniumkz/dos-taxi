export function MoneyIcon({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none">
      <defs>
        <linearGradient id="moneyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFD60A" />
          <stop offset="100%" stopColor="#FFB800" />
        </linearGradient>
      </defs>
      <circle cx="12" cy="12" r="10" fill="url(#moneyGrad)" />
      <path
        d="M12 6v2m0 8v2m-1-9h1.5a1.5 1.5 0 0 1 0 3H11m1 0h1.5a1.5 1.5 0 0 1 0 3H11"
        stroke="#1C1C1E"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}
