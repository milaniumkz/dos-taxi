export function PaymentIcon({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none">
      <defs>
        <linearGradient id="paymentGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#10B981" />
          <stop offset="100%" stopColor="#059669" />
        </linearGradient>
      </defs>
      <rect x="2" y="5" width="20" height="14" rx="3" fill="url(#paymentGrad)" />
      <rect x="2" y="9" width="20" height="3" fill="#065F46" opacity="0.3" />
      <rect x="4" y="14" width="6" height="2" rx="1" fill="white" opacity="0.8" />
    </svg>
  );
}
