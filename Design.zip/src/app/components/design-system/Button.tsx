import { ButtonHTMLAttributes, forwardRef } from 'react';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'primary', size = 'md', fullWidth = false, className = '', children, ...props }, ref) => {
    const baseStyles = 'rounded-[16px] font-medium transition-all duration-200 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed';

    const variants = {
      primary: 'bg-gradient-to-br from-[#FFD60A] to-[#FFB800] text-[#1C1C1E] hover:from-[#FFB800] hover:to-[#FFA500] shadow-[0_8px_32px_rgba(255,214,10,0.4),_0_4px_16px_rgba(0,0,0,0.1)] hover:shadow-[0_12px_48px_rgba(255,214,10,0.5),_0_6px_24px_rgba(0,0,0,0.15)]',
      secondary: 'bg-gradient-to-br from-[#1C1C1E] to-[#2C2C2E] text-white hover:from-[#2C2C2E] hover:to-[#3C3C3E] shadow-[0_8px_32px_rgba(0,0,0,0.3),_0_4px_16px_rgba(0,0,0,0.2)] hover:shadow-[0_12px_48px_rgba(0,0,0,0.4),_0_6px_24px_rgba(0,0,0,0.25)]',
      outline: 'border-2 border-[#1C1C1E] text-[#1C1C1E] hover:bg-[#1C1C1E] hover:text-white shadow-[0_4px_16px_rgba(0,0,0,0.1)] hover:shadow-[0_8px_32px_rgba(0,0,0,0.2)]',
      ghost: 'text-[#1C1C1E] hover:bg-[#F7F7F7] hover:shadow-[0_4px_16px_rgba(0,0,0,0.05)]'
    };

    const sizes = {
      sm: 'px-4 py-2 text-sm',
      md: 'px-6 py-3',
      lg: 'px-8 py-4 text-lg'
    };

    return (
      <button
        ref={ref}
        className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${fullWidth ? 'w-full' : ''} ${className}`}
        {...props}
      >
        {children}
      </button>
    );
  }
);

Button.displayName = 'Button';
