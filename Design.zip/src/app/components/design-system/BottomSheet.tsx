import { ReactNode } from 'react';

interface BottomSheetProps {
  children: ReactNode;
  height?: 'auto' | 'half' | 'full';
  className?: string;
}

export function BottomSheet({ children, height = 'auto', className = '' }: BottomSheetProps) {
  const heightStyles = {
    auto: 'max-h-[80vh]',
    half: 'h-[50vh]',
    full: 'h-[90vh]'
  };

  return (
    <div className={`
      fixed bottom-0 left-0 right-0 z-50
      bg-white/95 backdrop-blur-xl
      rounded-t-[32px]
      shadow-[0_-8px_32px_rgba(0,0,0,0.12)]
      ${heightStyles[height]}
      ${className}
    `}>
      {/* Drag Handle */}
      <div className="flex justify-center pt-3 pb-4">
        <div className="w-12 h-1.5 bg-[#D1D1D6] rounded-full" />
      </div>

      {/* Content */}
      <div className="px-5 pb-8 overflow-y-auto max-h-[calc(100%-2rem)]">
        {children}
      </div>
    </div>
  );
}
