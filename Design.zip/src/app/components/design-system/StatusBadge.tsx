interface StatusBadgeProps {
  status: 'active' | 'pending' | 'completed' | 'cancelled' | 'online' | 'offline';
  children: React.ReactNode;
}

export function StatusBadge({ status, children }: StatusBadgeProps) {
  const styles = {
    active: 'bg-[#2ECC71]/10 text-[#2ECC71] border-[#2ECC71]/20',
    pending: 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/20',
    completed: 'bg-[#3B82F6]/10 text-[#3B82F6] border-[#3B82F6]/20',
    cancelled: 'bg-[#EF4444]/10 text-[#EF4444] border-[#EF4444]/20',
    online: 'bg-[#2ECC71]/10 text-[#2ECC71] border-[#2ECC71]/20',
    offline: 'bg-[#6E6E73]/10 text-[#6E6E73] border-[#6E6E73]/20'
  };

  return (
    <span className={`
      inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full
      border text-sm font-medium
      ${styles[status]}
    `}>
      <span className={`w-1.5 h-1.5 rounded-full ${status === 'online' || status === 'active' ? 'bg-current' : ''}`} />
      {children}
    </span>
  );
}
