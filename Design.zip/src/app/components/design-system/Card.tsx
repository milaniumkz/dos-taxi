import { HTMLAttributes, forwardRef } from 'react';

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  glass?: boolean;
  elevated?: boolean;
  noPadding?: boolean;
}

export const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ glass = false, elevated = false, noPadding = false, className = '', children, ...props }, ref) => {
    const baseStyles = 'rounded-[20px] transition-all duration-300';

    const glassStyles = glass
      ? 'bg-white/85 backdrop-blur-xl border border-white/30'
      : 'bg-white border border-black/[0.08]';

    const shadowStyles = elevated
      ? 'shadow-[0_20px_60px_rgba(0,0,0,0.2),_0_8px_24px_rgba(0,0,0,0.15)]'
      : 'shadow-[0_8px_32px_rgba(0,0,0,0.15),_0_4px_16px_rgba(0,0,0,0.1)]';

    const paddingStyles = noPadding ? '' : 'p-4';

    return (
      <div
        ref={ref}
        className={`${baseStyles} ${glassStyles} ${shadowStyles} ${paddingStyles} ${className}`}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Card.displayName = 'Card';
