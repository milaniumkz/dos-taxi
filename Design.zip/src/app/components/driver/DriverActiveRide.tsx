import { useState } from 'react';
import { Card } from '../design-system/Card';
import { Button } from '../design-system/Button';
import { StatusBadge } from '../design-system/StatusBadge';

interface DriverActiveRideProps {
  onComplete: () => void;
}

export function DriverActiveRide({ onComplete }: DriverActiveRideProps) {
  const [status, setStatus] = useState<'arriving' | 'waiting' | 'started' | 'completing'>('arriving');

  const passenger = {
    name: 'Анна Смирнова',
    rating: 4.8,
    photo: '👩'
  };

  const trip = {
    pickup: 'Проспект Абая, 15',
    destination: 'Назарбаев Университет',
    price: '720₸'
  };

  const handleStatusChange = () => {
    if (status === 'arriving') setStatus('waiting');
    else if (status === 'waiting') setStatus('started');
    else if (status === 'started') setStatus('completing');
    else onComplete();
  };

  const getStatusText = () => {
    switch (status) {
      case 'arriving': return 'Едете к клиенту';
      case 'waiting': return 'Ожидаете пассажира';
      case 'started': return 'В поездке';
      case 'completing': return 'Завершение';
    }
  };

  const getButtonText = () => {
    switch (status) {
      case 'arriving': return 'Я на месте';
      case 'waiting': return 'Начать поездку';
      case 'started': return 'Завершить поездку';
      case 'completing': return 'Подтвердить';
    }
  };

  return (
    <div className="h-screen relative overflow-hidden bg-[#F7F7F7]">
      {/* Navigation Map */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#E8F5E9] to-[#B2DFDB]">
        {/* Route */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path
            d="M 50 80 L 50 50 L 70 20"
            stroke="#FFD60A"
            strokeWidth="1.5"
            fill="none"
            strokeLinecap="round"
            strokeDasharray="4,4"
            className="animate-[dash_20s_linear_infinite]"
          />
        </svg>

        {/* Driver Position */}
        <div className="absolute" style={{ top: '50%', left: '50%' }}>
          <div className="w-14 h-14 bg-[#1C1C1E] rounded-full shadow-2xl flex items-center justify-center">
            <svg className="w-7 h-7 text-[#FFD60A]" fill="currentColor" viewBox="0 0 24 24">
              <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z" />
            </svg>
          </div>
        </div>

        {/* Destination */}
        <div className="absolute" style={{ top: '20%', left: '70%' }}>
          <div className="w-12 h-12 bg-[#FFD60A] rounded-full shadow-xl flex items-center justify-center animate-pulse">
            <svg className="w-6 h-6 text-[#1C1C1E]" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
            </svg>
          </div>
        </div>
      </div>

      {/* Top Status Bar */}
      <div className="absolute top-4 left-4 right-4 z-20">
        <Card glass className="!p-4">
          <StatusBadge status="active">{getStatusText()}</StatusBadge>
        </Card>
      </div>

      {/* Bottom Control Panel */}
      <div className="absolute bottom-0 left-0 right-0 z-30">
        <div className="bg-white/95 backdrop-blur-xl rounded-t-[32px] shadow-[0_-8px_32px_rgba(0,0,0,0.12)] p-6 pb-8">
          {/* Drag Handle */}
          <div className="flex justify-center mb-4">
            <div className="w-12 h-1.5 bg-[#D1D1D6] rounded-full" />
          </div>

          {/* Passenger Info */}
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-[#3B82F6] to-[#2563EB] rounded-[20px] flex items-center justify-center text-3xl shadow-lg">
              {passenger.photo}
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold">{passenger.name}</h3>
              <div className="flex items-center gap-2 text-sm">
                <span className="text-[#FFD60A]">★</span>
                <span className="font-medium">{passenger.rating}</span>
                <span className="text-[#6E6E73]">Рейтинг пассажира</span>
              </div>
            </div>
            <button className="p-3 bg-[#2ECC71] rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 active:scale-95">
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
            </button>
          </div>

          {/* Trip Progress */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-[#6E6E73]">Прогресс поездки</span>
              <span className="text-sm font-medium">
                {status === 'arriving' && '33%'}
                {status === 'waiting' && '66%'}
                {status === 'started' && '90%'}
                {status === 'completing' && '100%'}
              </span>
            </div>
            <div className="h-2 bg-[#E5E5E7] rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#FFD60A] to-[#FFB800] transition-all duration-500 rounded-full"
                style={{
                  width: status === 'arriving' ? '33%' : status === 'waiting' ? '66%' : status === 'started' ? '90%' : '100%'
                }}
              />
            </div>

            {/* Status Steps */}
            <div className="flex justify-between mt-3 text-xs">
              <span className={status === 'arriving' ? 'text-[#FFD60A] font-medium' : 'text-[#6E6E73]'}>
                Прибытие
              </span>
              <span className={status === 'waiting' ? 'text-[#FFD60A] font-medium' : 'text-[#6E6E73]'}>
                Ожидание
              </span>
              <span className={status === 'started' ? 'text-[#FFD60A] font-medium' : 'text-[#6E6E73]'}>
                В пути
              </span>
              <span className={status === 'completing' ? 'text-[#FFD60A] font-medium' : 'text-[#6E6E73]'}>
                Конец
              </span>
            </div>
          </div>

          {/* Route Details */}
          <Card className="!p-4 mb-6" noPadding={false}>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-[#2ECC71] rounded-full flex items-center justify-center flex-shrink-0">
                  <div className="w-2 h-2 bg-white rounded-full" />
                </div>
                <div className="flex-1 text-sm">{trip.pickup}</div>
              </div>
              <div className="ml-4 border-l-2 border-dashed border-[#D1D1D6] h-4" />
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-[#FFD60A] rounded-full flex items-center justify-center flex-shrink-0">
                  <div className="w-2 h-2 bg-[#1C1C1E] rounded-full" />
                </div>
                <div className="flex-1 text-sm">{trip.destination}</div>
              </div>
            </div>
          </Card>

          {/* Price */}
          <div className="flex items-center justify-between mb-6 p-4 bg-gradient-to-r from-[#FFD60A] to-[#FFB800] rounded-[20px]">
            <span className="font-bold text-[#1C1C1E]">Стоимость поездки</span>
            <span className="text-3xl font-bold text-[#1C1C1E]" style={{ fontFamily: 'var(--font-display)' }}>
              {trip.price}
            </span>
          </div>

          {/* Action Button */}
          <Button
            variant="secondary"
            size="lg"
            fullWidth
            onClick={handleStatusChange}
            className="!py-4 shadow-xl"
          >
            {getButtonText()}
          </Button>
        </div>
      </div>

      <style>{`
        @keyframes dash {
          to {
            stroke-dashoffset: -100;
          }
        }
      `}</style>
    </div>
  );
}
