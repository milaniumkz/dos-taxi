import { Card } from '../design-system/Card';
import { Button } from '../design-system/Button';
import { Input } from '../design-system/Input';

interface DriverProfileScreenProps {
  onBack: () => void;
}

export function DriverProfileScreen({ onBack }: DriverProfileScreenProps) {
  const driver = {
    name: 'Алексей Иванов',
    phone: '+7 (777) 987-65-43',
    email: 'alexey.ivanov@email.com',
    rating: 4.9,
    trips: 1234,
    photo: '👨',
    car: {
      brand: 'Toyota',
      model: 'Camry',
      year: 2021,
      color: 'Черный',
      plate: 'A 777 BC'
    },
    documents: {
      license: 'Подтверждено ✓',
      registration: 'Подтверждено ✓',
      insurance: 'Подтверждено ✓'
    }
  };

  return (
    <div className="min-h-screen bg-[#F7F7F7] pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#FFD60A] via-[#FFB800] to-[#FFA500] p-6 pb-20">
        <button onClick={onBack} className="mb-6 p-2 hover:bg-black/10 rounded-lg transition-colors">
          <svg className="w-6 h-6 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        <h1 className="text-3xl font-bold text-[#1C1C1E] mb-2" style={{ fontFamily: 'var(--font-display)' }}>
          Профиль водителя
        </h1>
        <p className="text-[#1C1C1E]/70">Управление аккаунтом</p>
      </div>

      {/* Profile Card */}
      <div className="px-4 -mt-12 mb-6">
        <Card className="!p-6 text-center" elevated>
          <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-br from-[#FFD60A] to-[#FFB800] rounded-full flex items-center justify-center text-5xl shadow-xl">
            {driver.photo}
          </div>
          <h2 className="text-2xl font-bold mb-2" style={{ fontFamily: 'var(--font-display)' }}>
            {driver.name}
          </h2>

          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="flex items-center gap-1">
              <span className="text-[#FFD60A]">★</span>
              <span className="font-bold">{driver.rating}</span>
            </div>
            <div className="w-1 h-1 bg-[#D1D1D6] rounded-full" />
            <div className="text-[#6E6E73]">{driver.trips} поездок</div>
          </div>

          <Button variant="outline" size="sm" className="mx-auto">
            Редактировать профиль
          </Button>
        </Card>
      </div>

      {/* Driver Info */}
      <div className="px-4 mb-6">
        <h3 className="font-bold mb-3">Личная информация</h3>
        <Card className="!p-4 space-y-4">
          <Input
            label="Телефон"
            value={driver.phone}
            onChange={() => {}}
            readOnly
            icon={
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
            }
          />
          <Input
            label="Email"
            value={driver.email}
            onChange={() => {}}
            icon={
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
            }
          />
        </Card>
      </div>

      {/* Car Info */}
      <div className="px-4 mb-6">
        <h3 className="font-bold mb-3">Информация об автомобиле</h3>
        <Card className="!p-6 bg-gradient-to-br from-[#1C1C1E] to-[#2C2C2E] text-white" elevated>
          <div className="flex items-center gap-4 mb-4">
            <div className="text-4xl">🚗</div>
            <div className="flex-1">
              <div className="text-xl font-bold mb-1">
                {driver.car.brand} {driver.car.model}
              </div>
              <div className="text-sm opacity-70">
                {driver.car.year} · {driver.car.color}
              </div>
            </div>
          </div>
          <div className="p-3 bg-white/10 rounded-[12px] text-center">
            <div className="text-2xl font-bold tracking-wider" style={{ fontFamily: 'var(--font-display)' }}>
              {driver.car.plate}
            </div>
            <div className="text-xs opacity-70 mt-1">Гос. номер</div>
          </div>
        </Card>
      </div>

      {/* Documents Status */}
      <div className="px-4 mb-6">
        <h3 className="font-bold mb-3">Документы</h3>
        <div className="space-y-3">
          <Card className="!p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#2ECC71]/10 rounded-full flex items-center justify-center">
                  ✓
                </div>
                <div>
                  <div className="font-medium">Водительские права</div>
                  <div className="text-sm text-[#6E6E73]">{driver.documents.license}</div>
                </div>
              </div>
              <svg className="w-5 h-5 text-[#2ECC71]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </Card>

          <Card className="!p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#2ECC71]/10 rounded-full flex items-center justify-center">
                  ✓
                </div>
                <div>
                  <div className="font-medium">Регистрация ТС</div>
                  <div className="text-sm text-[#6E6E73]">{driver.documents.registration}</div>
                </div>
              </div>
              <svg className="w-5 h-5 text-[#2ECC71]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </Card>

          <Card className="!p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#2ECC71]/10 rounded-full flex items-center justify-center">
                  ✓
                </div>
                <div>
                  <div className="font-medium">Страховка</div>
                  <div className="text-sm text-[#6E6E73]">{driver.documents.insurance}</div>
                </div>
              </div>
              <svg className="w-5 h-5 text-[#2ECC71]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </Card>
        </div>
      </div>

      {/* Settings */}
      <div className="px-4 mb-6">
        <h3 className="font-bold mb-3">Настройки</h3>
        <div className="space-y-3">
          <Card className="!p-0" noPadding>
            <button className="w-full px-4 py-4 flex items-center justify-between hover:bg-black/5 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#F7F7F7] rounded-full flex items-center justify-center">
                  🔔
                </div>
                <div className="text-left">
                  <div className="font-medium">Уведомления</div>
                  <div className="text-sm text-[#6E6E73]">Управление оповещениями</div>
                </div>
              </div>
              <svg className="w-5 h-5 text-[#6E6E73]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </Card>

          <Card className="!p-0" noPadding>
            <button className="w-full px-4 py-4 flex items-center justify-between hover:bg-black/5 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#F7F7F7] rounded-full flex items-center justify-center">
                  💰
                </div>
                <div className="text-left">
                  <div className="font-medium">Вывод средств</div>
                  <div className="text-sm text-[#6E6E73]">Настройки платежей</div>
                </div>
              </div>
              <svg className="w-5 h-5 text-[#6E6E73]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </Card>

          <Card className="!p-0" noPadding>
            <button className="w-full px-4 py-4 flex items-center justify-between hover:bg-black/5 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#F7F7F7] rounded-full flex items-center justify-center">
                  ❓
                </div>
                <div className="text-left">
                  <div className="font-medium">Помощь и поддержка</div>
                  <div className="text-sm text-[#6E6E73]">Центр поддержки</div>
                </div>
              </div>
              <svg className="w-5 h-5 text-[#6E6E73]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </Card>
        </div>
      </div>

      {/* Logout */}
      <div className="px-4">
        <Button
          variant="outline"
          fullWidth
          className="!border-[#EF4444] !text-[#EF4444] hover:!bg-[#EF4444] hover:!text-white"
        >
          Выйти из аккаунта
        </Button>
      </div>
    </div>
  );
}
