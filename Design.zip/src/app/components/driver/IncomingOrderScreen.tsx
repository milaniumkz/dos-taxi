import { useState, useEffect } from 'react';
import { Button } from '../design-system/Button';
import { Card } from '../design-system/Card';

interface IncomingOrderScreenProps {
  onAccept: () => void;
  onDecline: () => void;
}

export function IncomingOrderScreen({ onAccept, onDecline }: IncomingOrderScreenProps) {
  const [timeLeft, setTimeLeft] = useState(15);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          onDecline();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [onDecline]);

  const order = {
    pickup: 'Проспект Абая, 15',
    destination: 'Назарбаев Университет',
    distance: '5.2 км',
    duration: '12 мин',
    price: '720₸',
    passengerRating: 4.8
  };

  return (
    <div className="h-screen bg-gradient-to-br from-[#FFD60A] via-[#FFB800] to-[#FFA500] flex items-center justify-center p-6 animate-[fadeIn_0.3s_ease-out]">
      <div className="w-full max-w-md">
        {/* Timer Ring */}
        <div className="relative w-32 h-32 mx-auto mb-8">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="45"
              fill="none"
              stroke="rgba(28, 28, 30, 0.2)"
              strokeWidth="8"
            />
            <circle
              cx="50"
              cy="50"
              r="45"
              fill="none"
              stroke="#1C1C1E"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={`${(timeLeft / 15) * 283} 283`}
              className="transition-all duration-1000"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="text-4xl font-bold text-[#1C1C1E]" style={{ fontFamily: 'var(--font-display)' }}>
                {timeLeft}
              </div>
              <div className="text-sm text-[#1C1C1E]/70">сек</div>
            </div>
          </div>
        </div>

        {/* Order Card */}
        <Card className="!p-6 mb-6 animate-[slideUp_0.5s_ease-out]" elevated>
          <h2 className="text-2xl font-bold mb-4 text-center" style={{ fontFamily: 'var(--font-display)' }}>
            Новый заказ
          </h2>

          {/* Route Info */}
          <div className="space-y-4 mb-6">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-[#2ECC71] rounded-full flex items-center justify-center flex-shrink-0">
                <div className="w-3 h-3 bg-white rounded-full" />
              </div>
              <div className="flex-1">
                <div className="text-xs text-[#6E6E73] mb-1">Откуда</div>
                <div className="font-medium">{order.pickup}</div>
              </div>
            </div>

            <div className="ml-5 border-l-2 border-dashed border-[#D1D1D6] h-6" />

            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-[#FFD60A] rounded-full flex items-center justify-center flex-shrink-0">
                <svg className="w-5 h-5 text-[#1C1C1E]" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                </svg>
              </div>
              <div className="flex-1">
                <div className="text-xs text-[#6E6E73] mb-1">Куда</div>
                <div className="font-medium">{order.destination}</div>
              </div>
            </div>
          </div>

          {/* Trip Details */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="text-center p-3 bg-[#F7F7F7] rounded-[12px]">
              <div className="text-lg font-bold" style={{ fontFamily: 'var(--font-display)' }}>
                {order.distance}
              </div>
              <div className="text-xs text-[#6E6E73]">Расстояние</div>
            </div>
            <div className="text-center p-3 bg-[#F7F7F7] rounded-[12px]">
              <div className="text-lg font-bold" style={{ fontFamily: 'var(--font-display)' }}>
                {order.duration}
              </div>
              <div className="text-xs text-[#6E6E73]">Время</div>
            </div>
            <div className="text-center p-3 bg-[#F7F7F7] rounded-[12px]">
              <div className="text-lg font-bold flex items-center justify-center gap-1" style={{ fontFamily: 'var(--font-display)' }}>
                <span className="text-[#FFD60A]">★</span> {order.passengerRating}
              </div>
              <div className="text-xs text-[#6E6E73]">Пассажир</div>
            </div>
          </div>

          {/* Price */}
          <div className="text-center p-4 bg-gradient-to-r from-[#FFD60A] to-[#FFB800] rounded-[16px] mb-6">
            <div className="text-4xl font-bold text-[#1C1C1E]" style={{ fontFamily: 'var(--font-display)' }}>
              {order.price}
            </div>
            <div className="text-sm text-[#1C1C1E]/70">Стоимость поездки</div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              size="lg"
              fullWidth
              onClick={onDecline}
              className="!border-2 !border-[#EF4444] !text-[#EF4444] hover:!bg-[#EF4444] hover:!text-white !py-4"
            >
              Отклонить
            </Button>
            <Button
              variant="secondary"
              size="lg"
              fullWidth
              onClick={onAccept}
              className="!py-4 !shadow-xl animate-[pulse_2s_ease-in-out_infinite]"
            >
              Принять
            </Button>
          </div>
        </Card>

        <p className="text-center text-[#1C1C1E]/70 text-sm">
          Автоотмена через {timeLeft} секунд
        </p>
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
