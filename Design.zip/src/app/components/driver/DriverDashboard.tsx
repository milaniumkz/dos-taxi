import { useState } from 'react';
import { Card } from '../design-system/Card';
import { StatusBadge } from '../design-system/StatusBadge';

interface DriverDashboardProps {
  onNewOrder: () => void;
  onOpenEarnings: () => void;
  onOpenProfile?: () => void;
}

export function DriverDashboard({ onNewOrder, onOpenEarnings, onOpenProfile }: DriverDashboardProps) {
  const [isOnline, setIsOnline] = useState(false);

  return (
    <div className="h-screen relative overflow-hidden bg-[#F7F7F7]">
      {/* Map Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#E8F5E9] to-[#B2DFDB] opacity-50">
        <svg className="w-full h-full opacity-20" viewBox="0 0 100 100" preserveAspectRatio="none">
          <defs>
            <pattern id="driver-grid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#1C1C1E" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100" height="100" fill="url(#driver-grid)" />
        </svg>
      </div>

      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-20 p-4 pt-safe">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold" style={{ fontFamily: 'var(--font-display)' }}>
            DOS Такси Driver
          </h1>
          <button
            onClick={onOpenProfile}
            className="p-2 bg-white rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 active:scale-95"
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          </button>
        </div>

        {/* Online/Offline Toggle */}
        <Card glass elevated className="!p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold mb-1" style={{ fontFamily: 'var(--font-display)' }}>
                {isOnline ? 'Вы онлайн' : 'Вы оффлайн'}
              </h2>
              <p className="text-sm text-[#6E6E73]">
                {isOnline ? 'Ожидание заказов...' : 'Включите статус для приёма заказов'}
              </p>
            </div>
            <button
              onClick={() => setIsOnline(!isOnline)}
              className={`
                relative w-20 h-10 rounded-full transition-all duration-300 shadow-lg
                ${isOnline ? 'bg-[#2ECC71]' : 'bg-[#D1D1D6]'}
              `}
            >
              <div className={`
                absolute top-1 w-8 h-8 bg-white rounded-full shadow-md transition-all duration-300
                ${isOnline ? 'left-11' : 'left-1'}
              `} />
            </button>
          </div>

          <StatusBadge status={isOnline ? 'online' : 'offline'}>
            {isOnline ? 'Онлайн' : 'Оффлайн'}
          </StatusBadge>
        </Card>
      </div>

      {/* Center Area - Stats */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full px-4">
        {isOnline ? (
          <div className="text-center">
            <div className="w-32 h-32 mx-auto mb-6 relative">
              <div className="absolute inset-0 bg-[#FFD60A] rounded-full opacity-20 animate-ping" />
              <div className="absolute inset-0 bg-[#FFD60A] rounded-full flex items-center justify-center shadow-2xl">
                <svg className="w-16 h-16 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
            <h3 className="text-2xl font-bold mb-2" style={{ fontFamily: 'var(--font-display)' }}>
              Ожидание заказов
            </h3>
            <p className="text-[#6E6E73]">Скоро появится новый заказ</p>

            {/* Simulate new order after a delay */}
            <button
              onClick={onNewOrder}
              className="mt-6 px-6 py-3 bg-white rounded-[16px] shadow-lg hover:shadow-xl transition-all hover:scale-105 active:scale-95 font-medium"
            >
              Симуляция: Новый заказ
            </button>
          </div>
        ) : (
          <div className="text-center">
            <div className="w-32 h-32 mx-auto mb-6 bg-[#D1D1D6] rounded-full flex items-center justify-center shadow-xl">
              <svg className="w-16 h-16 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
              </svg>
            </div>
            <h3 className="text-2xl font-bold mb-2" style={{ fontFamily: 'var(--font-display)' }}>
              Отдыхаете
            </h3>
            <p className="text-[#6E6E73]">Включите статус онлайн для приёма заказов</p>
          </div>
        )}
      </div>

      {/* Bottom Stats */}
      <div className="absolute bottom-0 left-0 right-0 z-20 p-4 pb-24">
        <div className="grid grid-cols-3 gap-3">
          <Card className="!p-4 text-center" elevated>
            <div className="text-3xl font-bold text-[#FFD60A] mb-1" style={{ fontFamily: 'var(--font-display)' }}>
              12,450₸
            </div>
            <div className="text-xs text-[#6E6E73]">Сегодня</div>
          </Card>

          <Card className="!p-4 text-center" elevated>
            <div className="text-3xl font-bold text-[#2ECC71] mb-1" style={{ fontFamily: 'var(--font-display)' }}>
              8
            </div>
            <div className="text-xs text-[#6E6E73]">Поездок</div>
          </Card>

          <Card className="!p-4 text-center" elevated>
            <div className="text-3xl font-bold text-[#3B82F6] mb-1" style={{ fontFamily: 'var(--font-display)' }}>
              4.9
            </div>
            <div className="text-xs text-[#6E6E73]">Рейтинг</div>
          </Card>
        </div>
      </div>

      <style>{`
        @supports (padding: max(0px)) {
          .pt-safe {
            padding-top: max(1rem, env(safe-area-inset-top));
          }
          .pb-safe {
            padding-bottom: max(1rem, env(safe-area-inset-bottom));
          }
        }
      `}</style>
    </div>
  );
}
