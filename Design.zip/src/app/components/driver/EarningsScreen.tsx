import { Card } from '../design-system/Card';
import { Button } from '../design-system/Button';

interface EarningsScreenProps {
  onBack: () => void;
}

export function EarningsScreen({ onBack }: EarningsScreenProps) {
  const earnings = {
    today: 12450,
    week: 78900,
    month: 324500,
    balance: 256300
  };

  const recentTrips = [
    { id: 1, date: '14 апреля, 14:30', route: 'Абая → Университет', amount: 720, status: 'completed' },
    { id: 2, date: '14 апреля, 13:15', route: 'Достык → Mega', amount: 1250, status: 'completed' },
    { id: 3, date: '14 апреля, 11:45', route: 'Панфилова → Арбат', amount: 580, status: 'completed' },
    { id: 4, date: '14 апреля, 10:20', route: 'Furmanov → Almaty Tower', amount: 890, status: 'completed' },
    { id: 5, date: '14 апреля, 09:00', route: 'Жетысу → Достык Плаза', amount: 650, status: 'completed' }
  ];

  return (
    <div className="min-h-screen bg-[#F7F7F7] pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#FFD60A] via-[#FFB800] to-[#FFA500] p-6 pb-12">
        <button onClick={onBack} className="mb-6 p-2 hover:bg-black/10 rounded-lg transition-colors">
          <svg className="w-6 h-6 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        <h1 className="text-3xl font-bold text-[#1C1C1E] mb-2" style={{ fontFamily: 'var(--font-display)' }}>
          Заработок
        </h1>
        <p className="text-[#1C1C1E]/70">Ваша статистика и баланс</p>
      </div>

      {/* Stats Cards */}
      <div className="px-4 -mt-8 space-y-4 mb-6">
        {/* Balance Card */}
        <Card className="!p-6 bg-gradient-to-br from-[#1C1C1E] to-[#2C2C2E] text-white" elevated>
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-sm opacity-70 mb-1">Доступный баланс</div>
              <div className="text-4xl font-bold" style={{ fontFamily: 'var(--font-display)' }}>
                {earnings.balance.toLocaleString('ru-RU')} ₸
              </div>
            </div>
            <div className="w-16 h-16 bg-[#FFD60A] rounded-full flex items-center justify-center">
              <svg className="w-8 h-8 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
          <Button variant="primary" fullWidth className="!bg-[#FFD60A] !text-[#1C1C1E]">
            Вывести средства
          </Button>
        </Card>

        {/* Period Stats */}
        <div className="grid grid-cols-3 gap-3">
          <Card className="!p-4 text-center">
            <div className="text-2xl font-bold text-[#FFD60A] mb-1" style={{ fontFamily: 'var(--font-display)' }}>
              {earnings.today.toLocaleString('ru-RU')}₸
            </div>
            <div className="text-xs text-[#6E6E73]">Сегодня</div>
            <div className="text-xs text-[#2ECC71] mt-1">+8 поездок</div>
          </Card>

          <Card className="!p-4 text-center">
            <div className="text-2xl font-bold text-[#3B82F6] mb-1" style={{ fontFamily: 'var(--font-display)' }}>
              {earnings.week.toLocaleString('ru-RU')}₸
            </div>
            <div className="text-xs text-[#6E6E73]">Неделя</div>
            <div className="text-xs text-[#2ECC71] mt-1">+42 поездок</div>
          </Card>

          <Card className="!p-4 text-center">
            <div className="text-2xl font-bold text-[#8B5CF6] mb-1" style={{ fontFamily: 'var(--font-display)' }}>
              {(earnings.month / 1000).toFixed(0)}K₸
            </div>
            <div className="text-xs text-[#6E6E73]">Месяц</div>
            <div className="text-xs text-[#2ECC71] mt-1">+187 поездок</div>
          </Card>
        </div>
      </div>

      {/* Chart Placeholder */}
      <div className="px-4 mb-6">
        <Card className="!p-6">
          <h3 className="font-bold mb-4">Динамика за неделю</h3>
          <div className="flex items-end justify-between h-40 gap-2">
            {[65, 45, 80, 55, 90, 70, 100].map((height, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-2">
                <div className="w-full bg-gradient-to-t from-[#FFD60A] to-[#FFB800] rounded-t-lg transition-all hover:opacity-80" style={{ height: `${height}%` }} />
                <span className="text-xs text-[#6E6E73]">
                  {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'][i]}
                </span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recent Trips */}
      <div className="px-4">
        <h3 className="font-bold mb-3">Последние поездки</h3>
        <div className="space-y-3">
          {recentTrips.map((trip) => (
            <Card key={trip.id} className="!p-4 hover:shadow-xl transition-all">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="font-medium mb-1">{trip.route}</div>
                  <div className="text-xs text-[#6E6E73]">{trip.date}</div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-[#2ECC71]" style={{ fontFamily: 'var(--font-display)' }}>
                    +{trip.amount}₸
                  </div>
                  <div className="text-xs text-[#6E6E73]">Завершена</div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
