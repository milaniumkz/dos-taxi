import { Card } from '../design-system/Card';
import { StatusBadge } from '../design-system/StatusBadge';

interface DriverHistoryScreenProps {
  onBack: () => void;
}

export function DriverHistoryScreen({ onBack }: DriverHistoryScreenProps) {
  const trips = [
    {
      id: 1,
      date: '14 апреля, 14:30',
      from: 'Проспект Абая, 15',
      to: 'Назарбаев Университет',
      passenger: 'Анна С.',
      distance: '5.2 км',
      duration: '12 мин',
      earned: 720,
      rating: 5,
      status: 'completed' as const
    },
    {
      id: 2,
      date: '14 апреля, 13:15',
      from: 'Достык Плаза',
      to: 'Mega Silk Way',
      passenger: 'Игорь М.',
      distance: '8.4 км',
      duration: '18 мин',
      earned: 1250,
      rating: 4,
      status: 'completed' as const
    },
    {
      id: 3,
      date: '14 апреля, 11:45',
      from: 'Панфилова',
      to: 'Арбат',
      passenger: 'Мария К.',
      distance: '3.1 км',
      duration: '8 мин',
      earned: 580,
      rating: 5,
      status: 'completed' as const
    },
    {
      id: 4,
      date: '14 апреля, 10:20',
      from: 'Furmanov',
      to: 'Almaty Tower',
      passenger: 'Дмитрий П.',
      distance: '4.8 км',
      duration: '14 мин',
      earned: 890,
      rating: 5,
      status: 'completed' as const
    },
    {
      id: 5,
      date: '14 апреля, 09:00',
      from: 'Жетысу',
      to: 'Достык Плаза',
      passenger: 'Елена Б.',
      distance: '6.2 км',
      duration: '16 мин',
      earned: 650,
      rating: 4,
      status: 'completed' as const
    }
  ];

  const totalEarned = trips.reduce((sum, trip) => sum + trip.earned, 0);
  const totalTrips = trips.length;
  const avgRating = (trips.reduce((sum, trip) => sum + trip.rating, 0) / trips.length).toFixed(1);

  return (
    <div className="min-h-screen bg-[#F7F7F7] pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#FFD60A] via-[#FFB800] to-[#FFA500] p-6 pb-12">
        <button onClick={onBack} className="mb-6 p-2 hover:bg-black/10 rounded-lg transition-colors">
          <svg className="w-6 h-6 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        <h1 className="text-3xl font-bold text-[#1C1C1E] mb-2" style={{ fontFamily: 'var(--font-display)' }}>
          История поездок
        </h1>
        <p className="text-[#1C1C1E]/70">Все ваши выполненные заказы</p>
      </div>

      {/* Stats Summary */}
      <div className="px-4 -mt-8 mb-6">
        <Card className="!p-6 bg-gradient-to-br from-[#1C1C1E] to-[#2C2C2E] text-white" elevated>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-3xl font-bold mb-1" style={{ fontFamily: 'var(--font-display)' }}>
                {totalEarned}₸
              </div>
              <div className="text-xs opacity-70">Заработано</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-1" style={{ fontFamily: 'var(--font-display)' }}>
                {totalTrips}
              </div>
              <div className="text-xs opacity-70">Поездок</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-1 flex items-center justify-center gap-1" style={{ fontFamily: 'var(--font-display)' }}>
                <span className="text-[#FFD60A]">★</span> {avgRating}
              </div>
              <div className="text-xs opacity-70">Средний рейтинг</div>
            </div>
          </div>
        </Card>
      </div>

      {/* Filter by Date */}
      <div className="px-4 mb-4">
        <Card glass className="!p-2 flex gap-2">
          <button className="flex-1 py-2 px-3 rounded-[12px] bg-[#FFD60A] text-[#1C1C1E] text-sm font-medium shadow-md">
            Сегодня
          </button>
          <button className="flex-1 py-2 px-3 rounded-[12px] text-[#6E6E73] text-sm font-medium hover:bg-black/5">
            Неделя
          </button>
          <button className="flex-1 py-2 px-3 rounded-[12px] text-[#6E6E73] text-sm font-medium hover:bg-black/5">
            Месяц
          </button>
        </Card>
      </div>

      {/* Trips List */}
      <div className="px-4 space-y-3">
        {trips.map((trip) => (
          <Card key={trip.id} className="!p-4 hover:shadow-xl transition-all">
            {/* Header */}
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="font-bold">Поездка #{trip.id}</div>
                <div className="text-xs text-[#6E6E73]">{trip.date}</div>
              </div>
              <StatusBadge status={trip.status}>Завершена</StatusBadge>
            </div>

            {/* Route */}
            <div className="space-y-2 mb-3 p-3 bg-[#F7F7F7] rounded-[12px]">
              <div className="flex items-start gap-2">
                <div className="w-3 h-3 mt-1 bg-[#2ECC71] rounded-full flex-shrink-0" />
                <div className="text-sm flex-1">{trip.from}</div>
              </div>
              <div className="ml-1.5 border-l-2 border-dashed border-[#D1D1D6] h-4" />
              <div className="flex items-start gap-2">
                <div className="w-3 h-3 mt-1 bg-[#FFD60A] rounded-full flex-shrink-0" />
                <div className="text-sm flex-1">{trip.to}</div>
              </div>
            </div>

            {/* Details Grid */}
            <div className="grid grid-cols-3 gap-3 mb-3">
              <div className="text-center p-2 bg-[#F7F7F7] rounded-[8px]">
                <div className="text-sm font-bold">{trip.distance}</div>
                <div className="text-xs text-[#6E6E73]">Расстояние</div>
              </div>
              <div className="text-center p-2 bg-[#F7F7F7] rounded-[8px]">
                <div className="text-sm font-bold">{trip.duration}</div>
                <div className="text-xs text-[#6E6E73]">Время</div>
              </div>
              <div className="text-center p-2 bg-[#F7F7F7] rounded-[8px]">
                <div className="text-sm font-bold flex items-center justify-center gap-1">
                  {[...Array(trip.rating)].map((_, i) => (
                    <span key={i} className="text-[#FFD60A] text-xs">★</span>
                  ))}
                </div>
                <div className="text-xs text-[#6E6E73]">Оценка</div>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between pt-3 border-t border-black/5">
              <div className="text-sm text-[#6E6E73]">
                Пассажир: {trip.passenger}
              </div>
              <div className="text-2xl font-bold text-[#2ECC71]" style={{ fontFamily: 'var(--font-display)' }}>
                +{trip.earned}₸
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
