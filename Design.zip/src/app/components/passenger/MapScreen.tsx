import { useState } from 'react';
import { Card } from '../design-system/Card';
import { Input } from '../design-system/Input';
import { LocationIcon } from '../icons/LocationIcon';
import { TaxiIcon } from '../icons/TaxiIcon';
import { ScooterIcon } from '../icons/ScooterIcon';
import { DeliveryIcon } from '../icons/DeliveryIcon';
import { IntercityIcon } from '../icons/IntercityIcon';
import { ProfileIcon } from '../icons/ProfileIcon';
import { HistoryIcon } from '../icons/HistoryIcon';
import { PaymentIcon } from '../icons/PaymentIcon';

interface MapScreenProps {
  onBookRide: () => void;
  onOpenDelivery: () => void;
  onOpenIntercity: () => void;
  onOpenScooter: () => void;
}

export function MapScreen({ onBookRide, onOpenDelivery, onOpenIntercity, onOpenScooter }: MapScreenProps) {
  const [selectedService, setSelectedService] = useState<'taxi' | 'delivery' | 'intercity' | 'scooter'>('taxi');
  const [currentAddress, setCurrentAddress] = useState('Проспект Абая, 15, Алматы');
  const [editingAddress, setEditingAddress] = useState(false);

  return (
    <div className="h-screen relative overflow-hidden">
      {/* Mock Map Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#E8F5E9] to-[#B2DFDB]">
        {/* Mock Map Grid */}
        <svg className="w-full h-full opacity-20" viewBox="0 0 100 100" preserveAspectRatio="none">
          <defs>
            <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#1C1C1E" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100" height="100" fill="url(#grid)" />
        </svg>

        {/* Mock Roads */}
        <div className="absolute inset-0">
          <div className="absolute top-1/3 left-0 right-0 h-1 bg-white/60 transform -rotate-12" />
          <div className="absolute top-1/2 left-0 right-0 h-1.5 bg-white/80" />
          <div className="absolute left-1/4 top-0 bottom-0 w-1 bg-white/60" />
          <div className="absolute left-2/3 top-0 bottom-0 w-1 bg-white/60 transform rotate-6" />
        </div>

        {/* Nearby Vehicles - Taxis or Scooters based on selected service */}
        {selectedService === 'taxi' || selectedService === 'intercity' ? (
          // Nearby Cars (Yellow Pins)
          [
            { top: '35%', left: '25%' },
            { top: '60%', left: '70%' },
            { top: '45%', left: '50%' },
            { top: '70%', left: '30%' },
            { top: '25%', left: '60%' }
          ].map((pos, i) => (
            <div
              key={i}
              className="absolute w-8 h-8 animate-[pulse_2s_ease-in-out_infinite]"
              style={{ top: pos.top, left: pos.left, animationDelay: `${i * 0.3}s` }}
            >
              <div className="w-full h-full bg-[#FFD60A] rounded-full shadow-lg flex items-center justify-center">
                <svg className="w-4 h-4 text-[#1C1C1E]" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z" />
                </svg>
              </div>
            </div>
          ))
        ) : selectedService === 'scooter' ? (
          // Nearby Scooters (Green Pins)
          [
            { top: '30%', left: '40%', battery: 95 },
            { top: '50%', left: '60%', battery: 78 },
            { top: '40%', left: '25%', battery: 100 },
            { top: '65%', left: '45%', battery: 65 },
            { top: '25%', left: '70%', battery: 88 }
          ].map((scooter, i) => (
            <div
              key={i}
              className="absolute animate-[pulse_2s_ease-in-out_infinite]"
              style={{ top: scooter.top, left: scooter.left, animationDelay: `${i * 0.3}s` }}
            >
              <div className={`w-8 h-8 rounded-full shadow-lg flex items-center justify-center text-lg ${
                scooter.battery > 80 ? 'bg-[#2ECC71]' : scooter.battery > 50 ? 'bg-[#F59E0B]' : 'bg-[#EF4444]'
              }`}>
                🛴
              </div>
            </div>
          ))
        ) : selectedService === 'delivery' ? (
          // Delivery Zones (Package Icons)
          [
            { top: '35%', left: '30%' },
            { top: '55%', left: '65%' },
            { top: '45%', left: '45%' }
          ].map((pos, i) => (
            <div
              key={i}
              className="absolute w-8 h-8 animate-[pulse_2s_ease-in-out_infinite]"
              style={{ top: pos.top, left: pos.left, animationDelay: `${i * 0.4}s` }}
            >
              <div className="w-full h-full bg-[#3B82F6] rounded-full shadow-lg flex items-center justify-center text-lg">
                📦
              </div>
            </div>
          ))
        ) : null}

        {/* User Location Pin */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
          <div className="relative">
            <div className="w-12 h-12 bg-[#1C1C1E] rounded-full shadow-2xl flex items-center justify-center animate-[bounce_1s_ease-in-out_infinite]">
              <div className="w-3 h-3 bg-[#FFD60A] rounded-full" />
            </div>
            <div className="absolute inset-0 w-12 h-12 bg-[#1C1C1E] rounded-full opacity-20 animate-[ping_1.5s_ease-in-out_infinite]" />
          </div>
        </div>
      </div>

      {/* Top Bar - Current Location & Search */}
      <div className="absolute top-0 left-0 right-0 z-20 p-4 pt-safe space-y-3">
        {/* Current Location */}
        <Card glass className="!p-4 !shadow-[0_20px_60px_rgba(0,0,0,0.2),_0_8px_24px_rgba(0,0,0,0.15)]">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#2ECC71] to-[#27AE60] rounded-full flex items-center justify-center flex-shrink-0 mt-1 shadow-[0_4px_16px_rgba(46,204,113,0.4)]">
              <LocationIcon className="w-6 h-6" color="white" />
            </div>
            {editingAddress ? (
              <div className="flex-1">
                <Input
                  value={currentAddress}
                  onChange={(e) => setCurrentAddress(e.target.value)}
                  placeholder="Введите адрес"
                  className="!py-2"
                />
                <div className="flex gap-2 mt-2">
                  <button
                    onClick={() => setEditingAddress(false)}
                    className="px-3 py-1 bg-[#FFD60A] text-[#1C1C1E] rounded-lg text-sm font-medium"
                  >
                    Сохранить
                  </button>
                  <button
                    onClick={() => setEditingAddress(false)}
                    className="px-3 py-1 text-[#6E6E73] text-sm"
                  >
                    Отмена
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex-1">
                <div className="text-xs text-[#6E6E73] mb-1">Вы находитесь</div>
                <div className="font-medium text-sm">{currentAddress}</div>
              </div>
            )}
            {!editingAddress && (
              <button
                onClick={() => setEditingAddress(true)}
                className="p-2 hover:bg-black/5 rounded-lg transition-colors"
              >
                <svg className="w-5 h-5 text-[#6E6E73]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                </svg>
              </button>
            )}
          </div>
        </Card>

        {/* Search Bar */}
        <Card glass className="!p-0 overflow-hidden !shadow-[0_20px_60px_rgba(0,0,0,0.2),_0_8px_24px_rgba(0,0,0,0.15)]">
          <button
            onClick={selectedService === 'taxi' ? onBookRide : selectedService === 'intercity' ? onOpenIntercity : selectedService === 'scooter' ? onOpenScooter : onOpenDelivery}
            className="w-full px-5 py-4 text-left hover:bg-black/5 transition-colors group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#FFD60A] to-[#FFB800] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform shadow-[0_4px_16px_rgba(255,214,10,0.4)]">
                <svg className="w-5 h-5 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <span className="text-[#6E6E73] text-lg font-medium">
                {selectedService === 'taxi' && 'Куда поедем?'}
                {selectedService === 'intercity' && 'В какой город?'}
                {selectedService === 'scooter' && 'Найти самокат'}
                {selectedService === 'delivery' && 'Куда доставить?'}
              </span>
            </div>
          </button>

          {/* Service Tabs */}
          <div className="grid grid-cols-4 border-t border-black/5 bg-gradient-to-r from-white/50 to-white/30">
            <button
              onClick={() => setSelectedService('taxi')}
              className={`py-3 px-2 text-xs font-semibold transition-all relative ${
                selectedService === 'taxi'
                  ? 'text-[#1C1C1E]'
                  : 'text-[#6E6E73] hover:text-[#1C1C1E]'
              }`}
            >
              {selectedService === 'taxi' && (
                <div className="absolute inset-0 bg-gradient-to-br from-[#FFD60A] to-[#FFB800] opacity-20" />
              )}
              <div className="relative flex flex-col items-center gap-1">
                <TaxiIcon className="w-5 h-5" />
                <span>Такси</span>
              </div>
            </button>
            <button
              onClick={() => setSelectedService('intercity')}
              className={`py-3 px-2 text-xs font-semibold transition-all relative ${
                selectedService === 'intercity'
                  ? 'text-[#1C1C1E]'
                  : 'text-[#6E6E73] hover:text-[#1C1C1E]'
              }`}
            >
              {selectedService === 'intercity' && (
                <div className="absolute inset-0 bg-gradient-to-br from-[#FFD60A] to-[#FFB800] opacity-20" />
              )}
              <div className="relative flex flex-col items-center gap-1">
                <IntercityIcon className="w-5 h-5" />
                <span>Межгород</span>
              </div>
            </button>
            <button
              onClick={() => setSelectedService('scooter')}
              className={`py-3 px-2 text-xs font-semibold transition-all relative ${
                selectedService === 'scooter'
                  ? 'text-[#1C1C1E]'
                  : 'text-[#6E6E73] hover:text-[#1C1C1E]'
              }`}
            >
              {selectedService === 'scooter' && (
                <div className="absolute inset-0 bg-gradient-to-br from-[#FFD60A] to-[#FFB800] opacity-20" />
              )}
              <div className="relative flex flex-col items-center gap-1">
                <ScooterIcon className="w-5 h-5" />
                <span>Самокат</span>
              </div>
            </button>
            <button
              onClick={() => setSelectedService('delivery')}
              className={`py-3 px-2 text-xs font-semibold transition-all relative ${
                selectedService === 'delivery'
                  ? 'text-[#1C1C1E]'
                  : 'text-[#6E6E73] hover:text-[#1C1C1E]'
              }`}
            >
              {selectedService === 'delivery' && (
                <div className="absolute inset-0 bg-gradient-to-br from-[#FFD60A] to-[#FFB800] opacity-20" />
              )}
              <div className="relative flex flex-col items-center gap-1">
                <DeliveryIcon className="w-5 h-5" />
                <span>Доставка</span>
              </div>
            </button>
          </div>
        </Card>

        {/* Service Info Card */}
        {selectedService !== 'taxi' && (
          <Card glass className="!p-4 mt-3 !shadow-[0_12px_48px_rgba(0,0,0,0.18),_0_6px_24px_rgba(0,0,0,0.12)]">
            {selectedService === 'intercity' && (
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-[#8B5CF6] to-[#7C3AED] rounded-2xl flex items-center justify-center shadow-[0_4px_16px_rgba(139,92,246,0.4)]">
                  <IntercityIcon className="w-7 h-7" />
                </div>
                <div className="flex-1">
                  <div className="font-bold">Межгородние поездки</div>
                  <div className="text-sm text-[#6E6E73]">Комфортные поездки между городами</div>
                </div>
              </div>
            )}
            {selectedService === 'scooter' && (
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-[#2ECC71] to-[#27AE60] rounded-2xl flex items-center justify-center shadow-[0_4px_16px_rgba(46,204,113,0.4)]">
                  <ScooterIcon className="w-7 h-7" />
                </div>
                <div className="flex-1">
                  <div className="font-bold">Электросамокаты</div>
                  <div className="text-sm text-[#6E6E73]">Быстро и экологично по городу</div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-[#6E6E73]">от</div>
                  <div className="text-lg font-bold bg-gradient-to-br from-[#FFD60A] to-[#FFB800] bg-clip-text text-transparent">300₸</div>
                </div>
              </div>
            )}
            {selectedService === 'delivery' && (
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-[#3B82F6] to-[#2563EB] rounded-2xl flex items-center justify-center shadow-[0_4px_16px_rgba(59,130,246,0.4)]">
                  <DeliveryIcon className="w-7 h-7" />
                </div>
                <div className="flex-1">
                  <div className="font-bold">Доставка</div>
                  <div className="text-sm text-[#6E6E73]">Быстрая доставка по городу</div>
                </div>
              </div>
            )}
          </Card>
        )}
      </div>


      <style>{`
        @supports (padding: max(0px)) {
          .pt-safe {
            padding-top: max(1rem, env(safe-area-inset-top));
          }
          .pb-safe {
            padding-bottom: max(1rem, env(safe-area-inset-bottom));
          }
        }
      `}</style>
    </div>
  );
}
