import { useState } from 'react';
import { Card } from '../design-system/Card';
import { Button } from '../design-system/Button';
import { StatusBadge } from '../design-system/StatusBadge';

interface ActiveRideScreenProps {
  onComplete: () => void;
  onCancel: () => void;
}

export function ActiveRideScreen({ onComplete, onCancel }: ActiveRideScreenProps) {
  const [status, setStatus] = useState<'searching' | 'driver-found' | 'arriving' | 'in-progress'>('driver-found');

  const driver = {
    name: 'Алексей Иванов',
    photo: '👨',
    rating: 4.9,
    reviews: 1234,
    car: 'Toyota Camry',
    plate: 'A 777 BC',
    color: 'Черный'
  };

  return (
    <div className="h-screen relative overflow-hidden">
      {/* Map with Route */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#E8F5E9] to-[#B2DFDB]">
        {/* Active Route */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path
            d="M 20 70 Q 40 40, 80 30"
            stroke="#FFD60A"
            strokeWidth="1.2"
            fill="none"
            strokeLinecap="round"
          />
        </svg>

        {/* Driver Car (Animated) */}
        <div
          className="absolute transition-all duration-1000"
          style={{ top: '50%', left: '50%' }}
        >
          <div className="w-12 h-12 bg-[#FFD60A] rounded-full shadow-2xl flex items-center justify-center animate-pulse">
            <svg className="w-6 h-6 text-[#1C1C1E]" fill="currentColor" viewBox="0 0 24 24">
              <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z" />
            </svg>
          </div>
          {/* Pulse Effect */}
          <div className="absolute inset-0 w-12 h-12 bg-[#FFD60A] rounded-full opacity-30 animate-[ping_1.5s_ease-in-out_infinite]" />
        </div>

        {/* Destination */}
        <div className="absolute" style={{ top: '30%', left: '80%' }}>
          <div className="w-10 h-10 bg-[#1C1C1E] rounded-full shadow-xl flex items-center justify-center">
            <svg className="w-5 h-5 text-[#FFD60A]" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
            </svg>
          </div>
        </div>
      </div>

      {/* Status Bar */}
      <div className="absolute top-4 left-4 right-4 z-20">
        <Card glass className="!p-4 !shadow-[0_20px_60px_rgba(0,0,0,0.2),_0_8px_24px_rgba(0,0,0,0.15)]">
          <div className="flex items-center justify-between">
            <StatusBadge status="active">
              {status === 'driver-found' && '✓ Водитель найден'}
              {status === 'arriving' && '🚗 Водитель в пути'}
              {status === 'in-progress' && '🛣️ В поездке'}
            </StatusBadge>
            <button className="p-2 hover:bg-black/10 rounded-xl transition-all hover:scale-110 active:scale-95">
              <svg className="w-6 h-6 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </Card>
      </div>

      {/* Driver Info Card */}
      <div className="absolute bottom-0 left-0 right-0 z-30">
        <div className="bg-white/98 backdrop-blur-xl rounded-t-[32px] shadow-[0_-20px_60px_rgba(0,0,0,0.2),_0_-8px_24px_rgba(0,0,0,0.15)] p-6 pb-8">
          {/* Drag Handle */}
          <div className="flex justify-center mb-4">
            <div className="w-12 h-1.5 bg-[#D1D1D6] rounded-full" />
          </div>

          {/* ETA */}
          <div className="text-center mb-6 p-6 bg-gradient-to-br from-[#FFD60A]/20 to-[#FFB800]/10 rounded-[24px] border-2 border-[#FFD60A]/30">
            <div className="text-6xl font-extrabold bg-gradient-to-br from-[#FFD60A] to-[#FFB800] bg-clip-text text-transparent mb-2" style={{ fontFamily: 'var(--font-display)' }}>
              3 мин
            </div>
            <div className="text-[#1C1C1E] font-semibold">до прибытия водителя</div>
          </div>

          {/* Driver Card */}
          <Card className="!p-5 mb-5 !shadow-[0_12px_48px_rgba(0,0,0,0.15),_0_6px_24px_rgba(0,0,0,0.1)]" elevated>
            <div className="flex items-center gap-4">
              {/* Driver Photo */}
              <div className="w-20 h-20 bg-gradient-to-br from-[#FFD60A] to-[#FFB800] rounded-[24px] flex items-center justify-center text-4xl shadow-[0_8px_32px_rgba(255,214,10,0.4)]">
                {driver.photo}
              </div>

              {/* Driver Info */}
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="font-bold text-lg">{driver.name}</h4>
                  <div className="flex items-center gap-1 text-sm">
                    <span className="text-[#FFD60A]">★</span>
                    <span className="font-medium">{driver.rating}</span>
                    <span className="text-[#6E6E73]">({driver.reviews})</span>
                  </div>
                </div>
                <div className="text-sm text-[#6E6E73]">
                  {driver.car} · {driver.color}
                </div>
                <div className="text-lg font-bold mt-1">{driver.plate}</div>
              </div>
            </div>
          </Card>

          {/* Action Buttons */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            <button className="flex flex-col items-center gap-2 p-4 bg-[#F7F7F7] rounded-[16px] hover:bg-[#E5E5E7] transition-colors active:scale-95">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm">
                <svg className="w-6 h-6 text-[#2ECC71]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
              </div>
              <span className="text-xs font-medium">Звонок</span>
            </button>

            <button className="flex flex-col items-center gap-2 p-4 bg-[#F7F7F7] rounded-[16px] hover:bg-[#E5E5E7] transition-colors active:scale-95">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm">
                <svg className="w-6 h-6 text-[#3B82F6]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </div>
              <span className="text-xs font-medium">Чат</span>
            </button>

            <button className="flex flex-col items-center gap-2 p-4 bg-[#F7F7F7] rounded-[16px] hover:bg-[#E5E5E7] transition-colors active:scale-95">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm">
                <svg className="w-6 h-6 text-[#F59E0B]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                </svg>
              </div>
              <span className="text-xs font-medium">Поделиться</span>
            </button>
          </div>

          {/* Cancel / Complete */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              fullWidth
              onClick={onCancel}
              className="!border-[#EF4444] !text-[#EF4444] hover:!bg-[#EF4444] hover:!text-white"
            >
              Отменить
            </Button>
            <Button
              variant="primary"
              fullWidth
              onClick={onComplete}
              className="shadow-xl"
            >
              Завершить
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
