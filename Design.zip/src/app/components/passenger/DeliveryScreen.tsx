import { useState } from 'react';
import { Card } from '../design-system/Card';
import { Button } from '../design-system/Button';
import { Input } from '../design-system/Input';

interface DeliveryScreenProps {
  onBack: () => void;
  onConfirm: () => void;
}

export function DeliveryScreen({ onBack, onConfirm }: DeliveryScreenProps) {
  const [step, setStep] = useState<'form' | 'confirmation'>('form');

  return (
    <div className="min-h-screen bg-[#F7F7F7] pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#FFD60A] via-[#FFB800] to-[#FFA500] p-6 pb-12">
        <button onClick={onBack} className="mb-6 p-2 hover:bg-black/10 rounded-lg transition-colors">
          <svg className="w-6 h-6 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        <h1 className="text-3xl font-bold text-[#1C1C1E] mb-2" style={{ fontFamily: 'var(--font-display)' }}>
          📦 Доставка
        </h1>
        <p className="text-[#1C1C1E]/70">Отправьте посылку по городу</p>
      </div>

      <div className="px-4 -mt-8">
        {step === 'form' ? (
          <div className="space-y-4">
            {/* Sender */}
            <Card className="!p-6">
              <h3 className="font-bold mb-4 flex items-center gap-2">
                <span className="w-8 h-8 bg-[#2ECC71] rounded-full flex items-center justify-center text-white text-sm">1</span>
                Отправитель
              </h3>
              <div className="space-y-4">
                <Input
                  label="Адрес отправителя"
                  placeholder="Откуда забрать"
                  defaultValue=""
                  icon={
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  }
                />
                <div className="grid grid-cols-2 gap-4">
                  <Input
                    label="Имя"
                    placeholder="Ваше имя"
                    defaultValue=""
                  />
                  <Input
                    label="Телефон"
                    placeholder="+7 (___)"
                    defaultValue=""
                  />
                </div>
              </div>
            </Card>

            {/* Receiver */}
            <Card className="!p-6">
              <h3 className="font-bold mb-4 flex items-center gap-2">
                <span className="w-8 h-8 bg-[#FFD60A] rounded-full flex items-center justify-center text-[#1C1C1E] text-sm">2</span>
                Получатель
              </h3>
              <div className="space-y-4">
                <Input
                  label="Адрес получателя"
                  placeholder="Куда доставить"
                  defaultValue=""
                  icon={
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  }
                />
                <div className="grid grid-cols-2 gap-4">
                  <Input
                    label="Имя"
                    placeholder="Имя получателя"
                    defaultValue=""
                  />
                  <Input
                    label="Телефон"
                    placeholder="+7 (___)"
                    defaultValue=""
                  />
                </div>
              </div>
            </Card>

            {/* Package Details */}
            <Card className="!p-6">
              <h3 className="font-bold mb-4 flex items-center gap-2">
                <span className="w-8 h-8 bg-[#3B82F6] rounded-full flex items-center justify-center text-white text-sm">3</span>
                Детали посылки
              </h3>
              <div className="space-y-4">
                <Input
                  label="Описание"
                  placeholder="Что отправляете?"
                  defaultValue=""
                />

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[#1C1C1E] mb-2">Размер</label>
                    <select className="w-full px-4 py-3 rounded-[16px] bg-white border border-black/[0.08] text-[#1C1C1E] focus:outline-none focus:ring-2 focus:ring-[#FFD60A] focus:border-transparent">
                      <option>Маленький</option>
                      <option>Средний</option>
                      <option>Большой</option>
                    </select>
                  </div>
                  <Input
                    label="Вес (кг)"
                    placeholder="0.5"
                    type="number"
                    defaultValue=""
                  />
                </div>

                {/* Photo Upload */}
                <div>
                  <label className="block text-sm font-medium text-[#1C1C1E] mb-2">Фото посылки</label>
                  <button className="w-full p-8 border-2 border-dashed border-[#D1D1D6] rounded-[16px] hover:border-[#FFD60A] transition-colors">
                    <div className="text-center">
                      <div className="text-4xl mb-2">📷</div>
                      <div className="text-sm text-[#6E6E73]">Нажмите для загрузки</div>
                    </div>
                  </button>
                </div>

                {/* Special Instructions */}
                <Input
                  label="Комментарий (необязательно)"
                  placeholder="Особые указания"
                  defaultValue=""
                />
              </div>
            </Card>

            {/* Price Estimate */}
            <Card className="!p-6 bg-gradient-to-br from-[#FFD60A] to-[#FFB800]">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-[#1C1C1E]/70 mb-1">Стоимость доставки</div>
                  <div className="text-3xl font-bold text-[#1C1C1E]" style={{ fontFamily: 'var(--font-display)' }}>
                    450-580₸
                  </div>
                </div>
                <div className="text-5xl">📦</div>
              </div>
            </Card>

            <Button
              variant="primary"
              size="lg"
              fullWidth
              onClick={() => setStep('confirmation')}
              className="!py-4 shadow-xl"
            >
              Заказать доставку
            </Button>
          </div>
        ) : (
          <Card className="!p-8 text-center animate-[fadeIn_0.5s_ease-out]">
            <div className="w-24 h-24 mx-auto mb-6 bg-[#2ECC71] rounded-full flex items-center justify-center">
              <svg className="w-12 h-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold mb-2" style={{ fontFamily: 'var(--font-display)' }}>
              Заказ оформлен!
            </h2>
            <p className="text-[#6E6E73] mb-6">
              Курьер скоро прибудет по адресу отправителя
            </p>
            <div className="flex gap-3">
              <Button variant="outline" fullWidth onClick={onBack}>
                На главную
              </Button>
              <Button variant="primary" fullWidth onClick={onConfirm}>
                Отследить
              </Button>
            </div>
          </Card>
        )}
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </div>
  );
}
