import { useState } from 'react';
import { Card } from '../design-system/Card';
import { Button } from '../design-system/Button';

interface ScooterRentalScreenProps {
  onBack: () => void;
  onRent: (scooterId: string) => void;
}

export function ScooterRentalScreen({ onBack, onRent }: ScooterRentalScreenProps) {
  const [selectedScooter, setSelectedScooter] = useState<string | null>(null);
  const [rentalDuration, setRentalDuration] = useState('15min');
  const [showQRScanner, setShowQRScanner] = useState(false);
  const [scanningQR, setScanningQR] = useState(false);

  const nearbyScooters = [
    { id: '1', battery: 95, distance: '50м', position: { top: '30%', left: '40%' } },
    { id: '2', battery: 78, distance: '120м', position: { top: '50%', left: '60%' } },
    { id: '3', battery: 100, distance: '200м', position: { top: '40%', left: '25%' } },
    { id: '4', battery: 65, distance: '300м', position: { top: '65%', left: '45%' } }
  ];

  const pricingPlans = [
    { id: '15min', duration: '15 минут', price: 300, perMinute: 20 },
    { id: '30min', duration: '30 минут', price: 500, perMinute: 17 },
    { id: '1hour', duration: '1 час', price: 900, perMinute: 15 },
    { id: 'day', duration: 'День (12ч)', price: 5000, perMinute: 7 }
  ];

  const handleScanQR = () => {
    setShowQRScanner(true);
    setScanningQR(true);

    // Симуляция сканирования QR-кода
    setTimeout(() => {
      setScanningQR(false);
      const randomScooter = nearbyScooters[Math.floor(Math.random() * nearbyScooters.length)];
      setSelectedScooter(randomScooter.id);
      setShowQRScanner(false);
    }, 2000);
  };

  const handleUnlock = () => {
    if (selectedScooter) {
      onRent(selectedScooter);
    }
  };

  return (
    <div className="min-h-screen bg-[#F7F7F7] pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#FFD60A] via-[#FFB800] to-[#FFA500] p-6 pb-12">
        <button onClick={onBack} className="mb-6 p-2 hover:bg-black/10 rounded-lg transition-colors">
          <svg className="w-6 h-6 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        <h1 className="text-3xl font-bold text-[#1C1C1E] mb-2" style={{ fontFamily: 'var(--font-display)' }}>
          🛴 Аренда самоката
        </h1>
        <p className="text-[#1C1C1E]/70">Быстро и удобно по городу</p>
      </div>

      <div className="px-4 -mt-8 space-y-4">
        {/* Map with Scooters */}
        <Card className="!p-0 overflow-hidden h-[300px] relative" noPadding>
          {/* Mock Map */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#E8F5E9] to-[#B2DFDB]">
            <svg className="w-full h-full opacity-20" viewBox="0 0 100 100" preserveAspectRatio="none">
              <defs>
                <pattern id="scooter-grid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#1C1C1E" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100" height="100" fill="url(#scooter-grid)" />
            </svg>

            {/* Scooter Pins */}
            {nearbyScooters.map((scooter) => (
              <button
                key={scooter.id}
                onClick={() => setSelectedScooter(scooter.id)}
                className={`absolute transition-all ${
                  selectedScooter === scooter.id ? 'z-20 scale-125' : 'z-10'
                }`}
                style={{ top: scooter.position.top, left: scooter.position.left }}
              >
                <div className={`relative ${
                  selectedScooter === scooter.id ? 'animate-bounce' : ''
                }`}>
                  <div className={`w-10 h-10 rounded-full shadow-xl flex items-center justify-center text-xl ${
                    selectedScooter === scooter.id
                      ? 'bg-[#FFD60A]'
                      : scooter.battery > 80
                      ? 'bg-[#2ECC71]'
                      : scooter.battery > 50
                      ? 'bg-[#F59E0B]'
                      : 'bg-[#EF4444]'
                  }`}>
                    🛴
                  </div>
                  <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-white px-2 py-1 rounded-lg shadow-md text-xs font-bold whitespace-nowrap">
                    {scooter.battery}%
                  </div>
                </div>
              </button>
            ))}

            {/* User Location */}
            <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
              <div className="w-12 h-12 bg-[#1C1C1E] rounded-full shadow-2xl flex items-center justify-center">
                <div className="w-3 h-3 bg-[#FFD60A] rounded-full" />
              </div>
            </div>
          </div>

          {/* Legend */}
          <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-xl rounded-[12px] p-3 shadow-lg text-xs">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-3 h-3 bg-[#2ECC71] rounded-full" />
              <span>80%+</span>
            </div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-3 h-3 bg-[#F59E0B] rounded-full" />
              <span>50-80%</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-[#EF4444] rounded-full" />
              <span>&lt;50%</span>
            </div>
          </div>
        </Card>

        {/* Selected Scooter Info */}
        {selectedScooter && (
          <Card className="!p-6 animate-[slideUp_0.3s_ease-out]" elevated>
            <div className="flex items-center gap-4 mb-4">
              <div className="text-5xl">🛴</div>
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-1">Самокат #{selectedScooter}</h3>
                <div className="flex items-center gap-3 text-sm">
                  <span className="flex items-center gap-1">
                    <span className="text-[#2ECC71]">🔋</span>
                    {nearbyScooters.find(s => s.id === selectedScooter)?.battery}%
                  </span>
                  <span className="flex items-center gap-1">
                    <span>📍</span>
                    {nearbyScooters.find(s => s.id === selectedScooter)?.distance}
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 p-3 bg-[#F7F7F7] rounded-[12px]">
              <div className="text-center">
                <div className="font-bold">~25км</div>
                <div className="text-xs text-[#6E6E73]">Запас хода</div>
              </div>
              <div className="text-center">
                <div className="font-bold">25 км/ч</div>
                <div className="text-xs text-[#6E6E73]">Макс. скорость</div>
              </div>
              <div className="text-center">
                <div className="font-bold">⭐ 4.8</div>
                <div className="text-xs text-[#6E6E73]">Состояние</div>
              </div>
            </div>
          </Card>
        )}

        {/* Pricing Plans */}
        <div>
          <h3 className="font-bold mb-3 px-1">Выберите тариф</h3>
          <div className="space-y-3">
            {pricingPlans.map((plan) => (
              <button
                key={plan.id}
                onClick={() => setRentalDuration(plan.id)}
                className="w-full"
              >
                <Card
                  className={`!p-4 transition-all ${
                    rentalDuration === plan.id
                      ? 'ring-2 ring-[#FFD60A] scale-[1.02]'
                      : 'hover:shadow-lg'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="text-left">
                      <div className="font-bold text-lg">{plan.duration}</div>
                      <div className="text-sm text-[#6E6E73]">
                        {plan.perMinute}₸/мин
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-[#FFD60A]" style={{ fontFamily: 'var(--font-display)' }}>
                        {plan.price}₸
                      </div>
                      {plan.id === '1hour' && (
                        <span className="text-xs bg-[#2ECC71] text-white px-2 py-0.5 rounded-full">
                          Выгодно
                        </span>
                      )}
                    </div>
                  </div>
                </Card>
              </button>
            ))}
          </div>
        </div>

        {/* Safety Rules */}
        <Card className="!p-6 bg-[#3B82F6]/10 border-2 border-[#3B82F6]/20">
          <h3 className="font-bold mb-3 flex items-center gap-2">
            <span>⚠️</span>
            Правила безопасности
          </h3>
          <ul className="space-y-2 text-sm text-[#6E6E73]">
            <li>• Шлем обязателен</li>
            <li>• Максимальная скорость 25 км/ч</li>
            <li>• Запрещено в нетрезвом состоянии</li>
            <li>• Паркуйте в разрешенных зонах</li>
          </ul>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-3">
          {/* QR Scanner Button */}
          <Button
            variant="secondary"
            size="lg"
            fullWidth
            onClick={handleScanQR}
            className="!py-4 shadow-xl"
          >
            <svg className="w-6 h-6 inline mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z" />
            </svg>
            Сканировать QR-код
          </Button>

          {/* Manual Unlock Button */}
          <Button
            variant="primary"
            size="lg"
            fullWidth
            onClick={handleUnlock}
            disabled={!selectedScooter}
            className="!py-4 shadow-xl"
          >
            {selectedScooter ? 'Разблокировать самокат' : 'Выберите самокат на карте'}
          </Button>
        </div>
      </div>

      {/* QR Scanner Modal */}
      {showQRScanner && (
        <div className="absolute inset-0 bg-black z-50 flex flex-col items-center justify-center p-6 animate-[fadeIn_0.3s_ease-out]">
          <button
            onClick={() => setShowQRScanner(false)}
            className="absolute top-8 right-8 p-3 bg-white/10 rounded-full hover:bg-white/20 transition-colors"
          >
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-white mb-2" style={{ fontFamily: 'var(--font-display)' }}>
              Сканирование QR-кода
            </h2>
            <p className="text-white/70">Наведите камеру на QR-код самоката</p>
          </div>

          {/* QR Scanner Frame */}
          <div className="relative w-80 h-80 mb-8">
            {/* Scanning Frame */}
            <div className="absolute inset-0 border-4 border-white/30 rounded-[32px]">
              {/* Corner Markers */}
              <div className="absolute top-0 left-0 w-16 h-16 border-t-4 border-l-4 border-[#FFD60A] rounded-tl-[32px]" />
              <div className="absolute top-0 right-0 w-16 h-16 border-t-4 border-r-4 border-[#FFD60A] rounded-tr-[32px]" />
              <div className="absolute bottom-0 left-0 w-16 h-16 border-b-4 border-l-4 border-[#FFD60A] rounded-bl-[32px]" />
              <div className="absolute bottom-0 right-0 w-16 h-16 border-b-4 border-r-4 border-[#FFD60A] rounded-br-[32px]" />
            </div>

            {/* Scanning Animation */}
            {scanningQR && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-full h-1 bg-[#FFD60A] animate-[scan_2s_ease-in-out_infinite]" />
              </div>
            )}

            {/* Mock QR Code */}
            <div className="absolute inset-0 flex items-center justify-center opacity-30">
              <div className="w-48 h-48 bg-white p-4 rounded-[16px]">
                <div className="w-full h-full grid grid-cols-8 grid-rows-8 gap-1">
                  {[...Array(64)].map((_, i) => (
                    <div
                      key={i}
                      className={`${Math.random() > 0.5 ? 'bg-black' : 'bg-white'}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {scanningQR ? (
            <div className="text-white text-center">
              <div className="w-12 h-12 mx-auto mb-3 border-4 border-[#FFD60A] border-t-transparent rounded-full animate-spin" />
              <p className="text-lg">Сканирование...</p>
            </div>
          ) : (
            <p className="text-white/70 text-center">Самокат найден! ✓</p>
          )}

          {/* Manual Input */}
          <div className="mt-8">
            <button className="text-white/70 hover:text-white transition-colors underline">
              Ввести код вручную
            </button>
          </div>
        </div>
      )}

      <style>{`
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes scan {
          0%, 100% { transform: translateY(-100%); }
          50% { transform: translateY(100%); }
        }
      `}</style>
    </div>
  );
}
