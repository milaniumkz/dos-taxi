import { useState } from 'react';
import { Card } from '../design-system/Card';
import { StatusBadge } from '../design-system/StatusBadge';

interface HistoryScreenProps {
  onBack: () => void;
}

export function HistoryScreen({ onBack }: HistoryScreenProps) {
  const [filter, setFilter] = useState<'all' | 'taxi' | 'delivery'>('all');

  const trips = [
    {
      id: 1,
      type: 'taxi' as const,
      date: '14 апреля, 14:30',
      from: 'Проспект Абая, 15',
      to: 'Назарбаев Университет',
      driver: 'Алексей И.',
      price: 720,
      status: 'completed' as const,
      rating: 5
    },
    {
      id: 2,
      type: 'taxi' as const,
      date: '13 апреля, 18:45',
      from: 'Достык Плаза',
      to: 'Mega Silk Way',
      driver: 'Сергей К.',
      price: 1250,
      status: 'completed' as const,
      rating: 4
    },
    {
      id: 3,
      type: 'delivery' as const,
      date: '12 апреля, 12:20',
      from: 'Almaty Towers',
      to: 'Esentai Mall',
      driver: 'Марат Б.',
      price: 450,
      status: 'completed' as const,
      rating: 5
    },
    {
      id: 4,
      type: 'taxi' as const,
      date: '11 апреля, 09:15',
      from: 'Аэропорт Алматы',
      to: 'Отель Rixos',
      driver: 'Дмитрий М.',
      price: 2300,
      status: 'completed' as const,
      rating: 5
    },
    {
      id: 5,
      type: 'taxi' as const,
      date: '10 апреля, 21:00',
      from: 'Dostyk',
      to: 'Арбат',
      driver: 'Андрей П.',
      price: 580,
      status: 'cancelled' as const,
      rating: 0
    }
  ];

  const filteredTrips = filter === 'all'
    ? trips
    : trips.filter(trip => trip.type === filter);

  return (
    <div className="min-h-screen bg-[#F7F7F7] pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#FFD60A] via-[#FFB800] to-[#FFA500] p-6 pb-8">
        <button onClick={onBack} className="mb-6 p-2 hover:bg-black/10 rounded-lg transition-colors">
          <svg className="w-6 h-6 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        <h1 className="text-3xl font-bold text-[#1C1C1E] mb-2" style={{ fontFamily: 'var(--font-display)' }}>
          История поездок
        </h1>
        <p className="text-[#1C1C1E]/70">Все ваши поездки и доставки</p>
      </div>

      {/* Filters */}
      <div className="px-4 -mt-4 mb-6">
        <Card glass className="!p-2 flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`flex-1 py-2 px-4 rounded-[12px] text-sm font-medium transition-all ${
              filter === 'all'
                ? 'bg-[#FFD60A] text-[#1C1C1E] shadow-md'
                : 'text-[#6E6E73] hover:bg-black/5'
            }`}
          >
            Все
          </button>
          <button
            onClick={() => setFilter('taxi')}
            className={`flex-1 py-2 px-4 rounded-[12px] text-sm font-medium transition-all ${
              filter === 'taxi'
                ? 'bg-[#FFD60A] text-[#1C1C1E] shadow-md'
                : 'text-[#6E6E73] hover:bg-black/5'
            }`}
          >
            🚕 Такси
          </button>
          <button
            onClick={() => setFilter('delivery')}
            className={`flex-1 py-2 px-4 rounded-[12px] text-sm font-medium transition-all ${
              filter === 'delivery'
                ? 'bg-[#FFD60A] text-[#1C1C1E] shadow-md'
                : 'text-[#6E6E73] hover:bg-black/5'
            }`}
          >
            📦 Доставка
          </button>
        </Card>
      </div>

      {/* Trip List */}
      <div className="px-4 space-y-3">
        {filteredTrips.map((trip) => (
          <Card key={trip.id} className="!p-0 overflow-hidden hover:shadow-xl transition-all" noPadding>
            <div className="p-4">
              {/* Header */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{trip.type === 'taxi' ? '🚕' : '📦'}</span>
                  <div>
                    <div className="font-bold">{trip.type === 'taxi' ? 'Такси' : 'Доставка'}</div>
                    <div className="text-xs text-[#6E6E73]">{trip.date}</div>
                  </div>
                </div>
                <StatusBadge status={trip.status}>
                  {trip.status === 'completed' ? 'Завершена' : 'Отменена'}
                </StatusBadge>
              </div>

              {/* Route */}
              <div className="space-y-2 mb-3">
                <div className="flex items-start gap-2">
                  <div className="w-3 h-3 mt-1 bg-[#2ECC71] rounded-full flex-shrink-0" />
                  <div className="text-sm flex-1">{trip.from}</div>
                </div>
                <div className="ml-1.5 border-l-2 border-dashed border-[#D1D1D6] h-4" />
                <div className="flex items-start gap-2">
                  <div className="w-3 h-3 mt-1 bg-[#FFD60A] rounded-full flex-shrink-0" />
                  <div className="text-sm flex-1">{trip.to}</div>
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-3 border-t border-black/5">
                <div className="flex items-center gap-3">
                  <span className="text-sm text-[#6E6E73]">Водитель: {trip.driver}</span>
                  {trip.rating > 0 && (
                    <div className="flex items-center gap-1">
                      {[...Array(trip.rating)].map((_, i) => (
                        <span key={i} className="text-[#FFD60A] text-sm">★</span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="text-xl font-bold" style={{ fontFamily: 'var(--font-display)' }}>
                  {trip.price}₸
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            {trip.status === 'completed' && (
              <div className="flex border-t border-black/5">
                <button className="flex-1 py-3 text-sm font-medium text-[#3B82F6] hover:bg-black/5 transition-colors">
                  Повторить
                </button>
                <button className="flex-1 py-3 text-sm font-medium text-[#6E6E73] hover:bg-black/5 transition-colors border-l border-black/5">
                  Чек
                </button>
              </div>
            )}
          </Card>
        ))}
      </div>

      {/* Empty State */}
      {filteredTrips.length === 0 && (
        <div className="px-4 py-20 text-center">
          <div className="text-6xl mb-4">📋</div>
          <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'var(--font-display)' }}>
            Пока пусто
          </h3>
          <p className="text-[#6E6E73]">Здесь появятся ваши поездки</p>
        </div>
      )}
    </div>
  );
}
