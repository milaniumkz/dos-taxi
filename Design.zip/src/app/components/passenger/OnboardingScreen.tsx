import { useState } from 'react';
import { Button } from '../design-system/Button';
import { Input } from '../design-system/Input';

interface OnboardingScreenProps {
  onComplete: () => void;
}

export function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  const [step, setStep] = useState<'language' | 'phone' | 'otp'>('language');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);

  const handleLanguageSelect = (lang: string) => {
    setStep('phone');
  };

  const handlePhoneSubmit = () => {
    if (phone) {
      setStep('otp');
    }
  };

  const handleOtpChange = (index: number, value: string) => {
    if (value.length <= 1 && /^\d*$/.test(value)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      // Auto-focus next input
      if (value && index < 5) {
        const nextInput = document.getElementById(`otp-${index + 1}`);
        nextInput?.focus();
      }
    }
  };

  const handleOtpSubmit = () => {
    if (otp.every(digit => digit !== '')) {
      onComplete();
    }
  };

  return (
    <div className="h-screen bg-gradient-to-br from-[#FFD60A] via-[#FFB800] to-[#FFA500] flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {step === 'language' && (
          <div className="text-center space-y-8 animate-[fadeIn_0.6s_ease-out]">
            <div className="space-y-4">
              <div className="relative w-28 h-28 mx-auto">
                <div className="absolute inset-0 bg-gradient-to-br from-[#FFD60A] to-[#FFB800] rounded-[32px] shadow-[0_24px_80px_rgba(255,214,10,0.4),_0_12px_32px_rgba(0,0,0,0.2)] animate-[float_3s_ease-in-out_infinite]" />
                <div className="absolute inset-[4px] bg-gradient-to-br from-[#1C1C1E] to-[#2C2C2E] rounded-[28px] flex items-center justify-center">
                  <svg className="w-16 h-16" viewBox="0 0 24 24" fill="none">
                    <defs>
                      <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#FFD60A" />
                        <stop offset="100%" stopColor="#FFB800" />
                      </linearGradient>
                    </defs>
                    <path
                      d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"
                      fill="url(#logoGrad)"
                    />
                  </svg>
                </div>
              </div>
              <h1 className="text-6xl font-extrabold tracking-tight" style={{ fontFamily: 'var(--font-display)', textShadow: '0 4px 24px rgba(0,0,0,0.3), 0 2px 8px rgba(0,0,0,0.2)' }}>
                <span className="text-[#1C1C1E]">DOS</span>{' '}
                <span className="text-[#1C1C1E]">Такси</span>
              </h1>
              <p className="text-[#1C1C1E]/80 text-xl font-semibold" style={{ textShadow: '0 2px 8px rgba(0,0,0,0.15)' }}>Премиум перевозки</p>
            </div>

            <div className="space-y-4">
              <button
                onClick={() => handleLanguageSelect('ru')}
                className="w-full p-5 bg-white/95 backdrop-blur-xl rounded-[24px] shadow-[0_12px_48px_rgba(0,0,0,0.15),_0_6px_24px_rgba(0,0,0,0.1)] hover:shadow-[0_20px_60px_rgba(0,0,0,0.2),_0_8px_24px_rgba(0,0,0,0.15)] transition-all hover:scale-105 active:scale-95 group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#3B82F6] to-[#2563EB] rounded-2xl flex items-center justify-center text-2xl shadow-[0_4px_16px_rgba(59,130,246,0.3)]">
                    🇷🇺
                  </div>
                  <span className="text-xl font-bold text-[#1C1C1E]">Русский</span>
                </div>
              </button>
              <button
                onClick={() => handleLanguageSelect('kz')}
                className="w-full p-5 bg-white/95 backdrop-blur-xl rounded-[24px] shadow-[0_12px_48px_rgba(0,0,0,0.15),_0_6px_24px_rgba(0,0,0,0.1)] hover:shadow-[0_20px_60px_rgba(0,0,0,0.2),_0_8px_24px_rgba(0,0,0,0.15)] transition-all hover:scale-105 active:scale-95 group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#10B981] to-[#059669] rounded-2xl flex items-center justify-center text-2xl shadow-[0_4px_16px_rgba(16,185,129,0.3)]">
                    🇰🇿
                  </div>
                  <span className="text-xl font-bold text-[#1C1C1E]">Қазақша</span>
                </div>
              </button>
            </div>
          </div>
        )}

        {step === 'phone' && (
          <div className="space-y-8 animate-[fadeIn_0.6s_ease-out]">
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-bold text-[#1C1C1E]" style={{ fontFamily: 'var(--font-display)' }}>
                Войти
              </h2>
              <p className="text-[#1C1C1E]/70">Введите номер телефона</p>
            </div>

            <div className="space-y-4">
              <Input
                type="tel"
                placeholder="+7 (___) ___-__-__"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="!bg-white/95 !py-4 text-lg"
                icon={
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                }
              />
              <Button
                variant="secondary"
                size="lg"
                fullWidth
                onClick={handlePhoneSubmit}
                className="!py-4"
              >
                Продолжить
              </Button>
            </div>
          </div>
        )}

        {step === 'otp' && (
          <div className="space-y-8 animate-[fadeIn_0.6s_ease-out]">
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-bold text-[#1C1C1E]" style={{ fontFamily: 'var(--font-display)' }}>
                Код подтверждения
              </h2>
              <p className="text-[#1C1C1E]/70">
                Отправили SMS на {phone}
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex gap-3 justify-center">
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    id={`otp-${index}`}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    className="w-12 h-14 text-center text-2xl font-bold bg-white/95 rounded-[16px] border-2 border-transparent focus:border-[#1C1C1E] focus:outline-none transition-all"
                  />
                ))}
              </div>

              <Button
                variant="secondary"
                size="lg"
                fullWidth
                onClick={handleOtpSubmit}
                disabled={!otp.every(d => d !== '')}
                className="!py-4"
              >
                Войти
              </Button>

              <button className="w-full text-[#1C1C1E]/70 hover:text-[#1C1C1E] transition-colors">
                Отправить код повторно
              </button>
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes float {
          0%, 100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-10px);
          }
        }
      `}</style>
    </div>
  );
}
