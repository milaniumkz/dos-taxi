import { useState, useEffect } from 'react';
import { Card } from '../design-system/Card';
import { Button } from '../design-system/Button';
import { StatusBadge } from '../design-system/StatusBadge';

interface ScooterActiveRideProps {
  scooterId: string;
  onEnd: () => void;
}

export function ScooterActiveRide({ scooterId, onEnd }: ScooterActiveRideProps) {
  const [duration, setDuration] = useState(0); // в секундах
  const [distance, setDistance] = useState(0); // в метрах
  const [isPaused, setIsPaused] = useState(false);
  const [showEndConfirm, setShowEndConfirm] = useState(false);

  // Таймер поездки
  useEffect(() => {
    if (!isPaused) {
      const timer = setInterval(() => {
        setDuration(prev => prev + 1);
        // Симуляция увеличения расстояния (примерно 20 км/ч = 5.5 м/с)
        setDistance(prev => prev + 5.5);
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [isPaused]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDistance = (meters: number) => {
    if (meters < 1000) {
      return `${Math.round(meters)} м`;
    }
    return `${(meters / 1000).toFixed(2)} км`;
  };

  const calculateCost = () => {
    const minutes = Math.floor(duration / 60);
    const baseCost = 300; // старт
    const perMinuteCost = 20; // за минуту
    return baseCost + (minutes * perMinuteCost);
  };

  const handlePauseLock = () => {
    setIsPaused(!isPaused);
  };

  const handleEndRide = () => {
    setShowEndConfirm(true);
  };

  return (
    <div className="h-screen relative overflow-hidden bg-[#F7F7F7]">
      {/* Map Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#E8F5E9] to-[#B2DFDB]">
        <svg className="w-full h-full opacity-20" viewBox="0 0 100 100" preserveAspectRatio="none">
          <defs>
            <pattern id="ride-grid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#1C1C1E" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100" height="100" fill="url(#ride-grid)" />
        </svg>

        {/* Route Trail */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path
            d="M 30 70 Q 40 50, 50 50 T 70 30"
            stroke="#2ECC71"
            strokeWidth="1"
            fill="none"
            strokeDasharray="3,3"
            className="animate-[dash_20s_linear_infinite]"
          />
        </svg>

        {/* Current Position */}
        <div className="absolute" style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}>
          <div className="relative">
            <div className="w-16 h-16 bg-[#2ECC71] rounded-full shadow-2xl flex items-center justify-center text-3xl animate-bounce">
              🛴
            </div>
            <div className="absolute inset-0 w-16 h-16 bg-[#2ECC71] rounded-full opacity-20 animate-ping" />
          </div>
        </div>
      </div>

      {/* Top Status Bar */}
      <div className="absolute top-0 left-0 right-0 z-20 p-4">
        <Card glass className="!p-4">
          <div className="flex items-center justify-between">
            <StatusBadge status={isPaused ? 'pending' : 'active'}>
              {isPaused ? '⏸️ На паузе' : '🛴 Едете'}
            </StatusBadge>
            <div className="flex items-center gap-2">
              <div className="px-3 py-1 bg-[#2ECC71] text-white rounded-full text-sm font-bold">
                🔋 85%
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Bottom Control Panel */}
      <div className="absolute bottom-0 left-0 right-0 z-30">
        <div className="bg-white/95 backdrop-blur-xl rounded-t-[32px] shadow-[0_-8px_32px_rgba(0,0,0,0.12)] p-6 pb-8">
          {/* Drag Handle */}
          <div className="flex justify-center mb-6">
            <div className="w-12 h-1.5 bg-[#D1D1D6] rounded-full" />
          </div>

          {/* Main Stats */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <Card className="!p-4 text-center bg-gradient-to-br from-[#FFD60A] to-[#FFB800]">
              <div className="text-3xl font-bold text-[#1C1C1E] mb-1" style={{ fontFamily: 'var(--font-display)' }}>
                {formatTime(duration)}
              </div>
              <div className="text-xs text-[#1C1C1E]/70">Время</div>
            </Card>

            <Card className="!p-4 text-center bg-gradient-to-br from-[#2ECC71] to-[#27AE60]">
              <div className="text-3xl font-bold text-white mb-1" style={{ fontFamily: 'var(--font-display)' }}>
                {formatDistance(distance)}
              </div>
              <div className="text-xs text-white/80">Расстояние</div>
            </Card>

            <Card className="!p-4 text-center bg-gradient-to-br from-[#3B82F6] to-[#2563EB]">
              <div className="text-3xl font-bold text-white mb-1" style={{ fontFamily: 'var(--font-display)' }}>
                {calculateCost()}₸
              </div>
              <div className="text-xs text-white/80">Стоимость</div>
            </Card>
          </div>

          {/* Scooter Info */}
          <Card className="!p-4 mb-6">
            <div className="flex items-center gap-3">
              <div className="text-4xl">🛴</div>
              <div className="flex-1">
                <div className="font-bold">Самокат #{scooterId}</div>
                <div className="text-sm text-[#6E6E73]">Макс. скорость: 25 км/ч</div>
              </div>
              <div className="text-right">
                <div className="text-2xl">⚡</div>
              </div>
            </div>
          </Card>

          {/* Speed Indicator */}
          <Card className="!p-4 mb-6 bg-[#F7F7F7]">
            <div className="text-center">
              <div className="text-sm text-[#6E6E73] mb-2">Текущая скорость</div>
              <div className="text-5xl font-bold text-[#2ECC71] mb-2" style={{ fontFamily: 'var(--font-display)' }}>
                {isPaused ? 0 : Math.floor(15 + Math.random() * 10)}
              </div>
              <div className="text-lg text-[#6E6E73]">км/ч</div>
            </div>
          </Card>

          {/* Control Buttons */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <Button
              variant={isPaused ? 'primary' : 'secondary'}
              size="lg"
              fullWidth
              onClick={handlePauseLock}
              className="!py-4"
            >
              {isPaused ? (
                <>
                  <svg className="w-5 h-5 inline mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                  Разблокировать
                </>
              ) : (
                <>
                  <svg className="w-5 h-5 inline mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
                  </svg>
                  Заблокировать
                </>
              )}
            </Button>

            <Button
              variant="outline"
              size="lg"
              fullWidth
              onClick={handleEndRide}
              className="!border-[#EF4444] !text-[#EF4444] hover:!bg-[#EF4444] hover:!text-white !py-4"
            >
              Завершить поездку
            </Button>
          </div>

          {/* Safety Tips */}
          <div className="p-3 bg-[#F59E0B]/10 border border-[#F59E0B]/20 rounded-[16px]">
            <div className="flex items-start gap-2">
              <span className="text-lg">⚠️</span>
              <div className="flex-1 text-xs text-[#6E6E73]">
                <strong>Безопасность:</strong> Соблюдайте ПДД, используйте велодорожки, паркуйте в разрешенных зонах
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* End Ride Confirmation Modal */}
      {showEndConfirm && (
        <div className="absolute inset-0 bg-black/50 z-50 flex items-center justify-center p-6 animate-[fadeIn_0.3s_ease-out]">
          <Card className="!p-6 max-w-sm w-full" elevated>
            <h3 className="text-xl font-bold mb-4 text-center" style={{ fontFamily: 'var(--font-display)' }}>
              Завершить поездку?
            </h3>

            <div className="mb-6 p-4 bg-[#F7F7F7] rounded-[16px]">
              <div className="flex justify-between mb-2">
                <span className="text-[#6E6E73]">Время:</span>
                <span className="font-bold">{formatTime(duration)}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-[#6E6E73]">Расстояние:</span>
                <span className="font-bold">{formatDistance(distance)}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-black/10">
                <span className="font-bold">Итого:</span>
                <span className="text-2xl font-bold text-[#2ECC71]" style={{ fontFamily: 'var(--font-display)' }}>
                  {calculateCost()}₸
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <Button variant="primary" size="lg" fullWidth onClick={onEnd}>
                Подтвердить и оплатить
              </Button>
              <Button variant="outline" fullWidth onClick={() => setShowEndConfirm(false)}>
                Продолжить поездку
              </Button>
            </div>
          </Card>
        </div>
      )}

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes dash {
          to { stroke-dashoffset: -100; }
        }
      `}</style>
    </div>
  );
}
