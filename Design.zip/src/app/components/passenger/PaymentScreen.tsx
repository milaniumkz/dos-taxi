import { useState } from 'react';
import { Card } from '../design-system/Card';
import { Button } from '../design-system/Button';
import { Input } from '../design-system/Input';

interface PaymentScreenProps {
  onBack: () => void;
}

export function PaymentScreen({ onBack }: PaymentScreenProps) {
  const [selectedMethod, setSelectedMethod] = useState('card1');
  const [showAddCard, setShowAddCard] = useState(false);

  const paymentMethods = [
    { id: 'card1', type: 'card', number: '•••• 4242', brand: 'Visa', default: true },
    { id: 'card2', type: 'card', number: '•••• 8888', brand: 'Mastercard', default: false },
    { id: 'cash', type: 'cash', name: 'Наличные' }
  ];

  return (
    <div className="min-h-screen bg-[#F7F7F7] pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#FFD60A] via-[#FFB800] to-[#FFA500] p-6 pb-12">
        <button onClick={onBack} className="mb-6 p-2 hover:bg-black/10 rounded-lg transition-colors">
          <svg className="w-6 h-6 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        <h1 className="text-3xl font-bold text-[#1C1C1E] mb-2" style={{ fontFamily: 'var(--font-display)' }}>
          Способы оплаты
        </h1>
        <p className="text-[#1C1C1E]/70">Управление платежами</p>
      </div>

      {/* Payment Methods */}
      <div className="px-4 -mt-8 mb-6">
        <div className="space-y-3">
          {paymentMethods.map((method) => (
            <button
              key={method.id}
              onClick={() => setSelectedMethod(method.id)}
              className={`w-full transition-all ${
                selectedMethod === method.id ? 'scale-[1.02]' : ''
              }`}
            >
              {method.type === 'card' ? (
                <Card
                  className={`!p-0 overflow-hidden ${
                    selectedMethod === method.id
                      ? 'ring-2 ring-[#FFD60A]'
                      : ''
                  }`}
                  elevated
                  noPadding
                >
                  <div className="bg-gradient-to-br from-[#1C1C1E] to-[#2C2C2E] p-6 text-white">
                    <div className="flex items-start justify-between mb-8">
                      <div className="text-2xl font-bold" style={{ fontFamily: 'var(--font-display)' }}>
                        {method.brand}
                      </div>
                      {method.default && (
                        <span className="px-2 py-1 bg-[#FFD60A] text-[#1C1C1E] text-xs rounded-full font-medium">
                          Основная
                        </span>
                      )}
                    </div>
                    <div className="text-2xl font-mono mb-2 tracking-wider">
                      {method.number}
                    </div>
                    <div className="text-sm opacity-70">Дебетовая карта</div>
                  </div>
                  <div className="p-4 bg-white flex items-center justify-between">
                    <span className="text-sm text-[#6E6E73]">
                      {selectedMethod === method.id ? '✓ Выбрана' : 'Нажмите для выбора'}
                    </span>
                    <button className="p-2 hover:bg-black/5 rounded-lg transition-colors">
                      <svg className="w-5 h-5 text-[#6E6E73]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                      </svg>
                    </button>
                  </div>
                </Card>
              ) : (
                <Card
                  className={`!p-4 ${
                    selectedMethod === method.id
                      ? 'ring-2 ring-[#FFD60A]'
                      : ''
                  }`}
                  elevated
                >
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-[#2ECC71] rounded-full flex items-center justify-center text-2xl">
                      💵
                    </div>
                    <div className="flex-1 text-left">
                      <div className="font-bold text-lg">{method.name}</div>
                      <div className="text-sm text-[#6E6E73]">Оплата водителю</div>
                    </div>
                    {selectedMethod === method.id && (
                      <div className="w-6 h-6 bg-[#2ECC71] rounded-full flex items-center justify-center">
                        <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                    )}
                  </div>
                </Card>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Add Card Button */}
      <div className="px-4 mb-6">
        <Button
          variant="outline"
          fullWidth
          onClick={() => setShowAddCard(!showAddCard)}
          className="!py-4"
        >
          <div className="flex items-center justify-center gap-2">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Добавить карту
          </div>
        </Button>
      </div>

      {/* Add Card Form */}
      {showAddCard && (
        <div className="px-4 mb-6 animate-[slideDown_0.3s_ease-out]">
          <Card className="!p-6" elevated>
            <h3 className="font-bold mb-4">Новая карта</h3>
            <div className="space-y-4">
              <Input
                label="Номер карты"
                placeholder="1234 5678 9012 3456"
                type="text"
                defaultValue=""
                icon={
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                  </svg>
                }
              />
              <div className="grid grid-cols-2 gap-4">
                <Input
                  label="Срок"
                  placeholder="MM/YY"
                  type="text"
                  defaultValue=""
                />
                <Input
                  label="CVV"
                  placeholder="123"
                  type="text"
                  defaultValue=""
                />
              </div>
              <Input
                label="Имя на карте"
                placeholder="ANNA SMIRNOVA"
                type="text"
                defaultValue=""
              />
              <Button variant="primary" fullWidth>
                Добавить карту
              </Button>
            </div>
          </Card>
        </div>
      )}

      {/* Promo Code */}
      <div className="px-4 mb-6">
        <Card className="!p-6">
          <h3 className="font-bold mb-4">Промокод</h3>
          <div className="flex gap-3">
            <Input
              placeholder="Введите промокод"
              className="flex-1"
              defaultValue=""
            />
            <Button variant="primary">
              Применить
            </Button>
          </div>
        </Card>
      </div>

      {/* Bonuses */}
      <div className="px-4">
        <Card className="!p-6 bg-gradient-to-br from-[#FFD60A] to-[#FFB800]">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-3xl">
              🎁
            </div>
            <div className="flex-1">
              <div className="font-bold text-[#1C1C1E] text-lg mb-1">Бонусный баланс</div>
              <div className="text-[#1C1C1E]/70 text-sm">Можно потратить на поездки</div>
            </div>
            <div className="text-3xl font-bold text-[#1C1C1E]" style={{ fontFamily: 'var(--font-display)' }}>
              450₸
            </div>
          </div>
        </Card>
      </div>

      <style>{`
        @keyframes slideDown {
          from {
            opacity: 0;
            transform: translateY(-20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
