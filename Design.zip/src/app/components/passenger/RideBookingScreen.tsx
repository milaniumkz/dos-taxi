import { useState } from 'react';
import { BottomSheet } from '../design-system/BottomSheet';
import { Button } from '../design-system/Button';
import { Card } from '../design-system/Card';

interface RideBookingScreenProps {
  onConfirm: (vehicle: string) => void;
  onBack: () => void;
}

const vehicles = [
  {
    id: 'economy',
    name: 'Эконом',
    description: 'Базовый тариф',
    eta: '2 мин',
    price: '450-520 ₸',
    icon: '🚗',
    passengers: 4
  },
  {
    id: 'comfort',
    name: 'Комфорт',
    description: 'Комфортные авто',
    eta: '4 мин',
    price: '680-780 ₸',
    icon: '🚙',
    passengers: 4,
    popular: true
  },
  {
    id: 'business',
    name: 'Бизнес',
    description: 'Премиум класс',
    eta: '6 мин',
    price: '1,200-1,400 ₸',
    icon: '🚘',
    passengers: 3
  }
];

export function RideBookingScreen({ onConfirm, onBack }: RideBookingScreenProps) {
  const [selectedVehicle, setSelectedVehicle] = useState('comfort');
  const [pickup] = useState('Проспект Абая, 15');
  const [destination] = useState('Назарбаев Университет');

  return (
    <div className="h-screen relative overflow-hidden">
      {/* Map with Route */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#E8F5E9] to-[#B2DFDB]">
        {/* Mock Route Path */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path
            d="M 20 70 Q 40 40, 80 30"
            stroke="#FFD60A"
            strokeWidth="0.8"
            fill="none"
            strokeDasharray="2,2"
            className="animate-[dash_20s_linear_infinite]"
          />
        </svg>

        {/* Pickup Pin */}
        <div className="absolute" style={{ top: '70%', left: '20%' }}>
          <div className="w-10 h-10 bg-[#2ECC71] rounded-full shadow-xl flex items-center justify-center animate-bounce">
            <div className="w-3 h-3 bg-white rounded-full" />
          </div>
        </div>

        {/* Destination Pin */}
        <div className="absolute" style={{ top: '30%', left: '80%' }}>
          <div className="w-10 h-10 bg-[#FFD60A] rounded-full shadow-xl flex items-center justify-center animate-pulse">
            <svg className="w-5 h-5 text-[#1C1C1E]" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
            </svg>
          </div>
        </div>
      </div>

      {/* Top Info Card */}
      <div className="absolute top-4 left-4 right-4 z-20">
        <Card glass className="!p-4 !shadow-[0_20px_60px_rgba(0,0,0,0.2),_0_8px_24px_rgba(0,0,0,0.15)]">
          <button onClick={onBack} className="mb-3 p-2 hover:bg-black/10 rounded-xl transition-all hover:scale-110 active:scale-95">
            <svg className="w-6 h-6 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 mt-0.5 bg-gradient-to-br from-[#2ECC71] to-[#27AE60] rounded-full shadow-[0_4px_16px_rgba(46,204,113,0.3)] flex items-center justify-center flex-shrink-0">
                <div className="w-2.5 h-2.5 bg-white rounded-full" />
              </div>
              <div className="flex-1">
                <div className="text-xs text-[#6E6E73] font-semibold mb-0.5">Откуда</div>
                <div className="font-bold text-[#1C1C1E]">{pickup}</div>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 mt-0.5 bg-gradient-to-br from-[#FFD60A] to-[#FFB800] rounded-full shadow-[0_4px_16px_rgba(255,214,10,0.4)] flex items-center justify-center flex-shrink-0">
                <svg className="w-4 h-4 text-[#1C1C1E]" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                </svg>
              </div>
              <div className="flex-1">
                <div className="text-xs text-[#6E6E73] font-semibold mb-0.5">Куда</div>
                <div className="font-bold text-[#1C1C1E]">{destination}</div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Bottom Sheet - Vehicle Selection */}
      <div className="absolute bottom-0 left-0 right-0 z-30">
        <div className="bg-white/98 backdrop-blur-xl rounded-t-[32px] shadow-[0_-20px_60px_rgba(0,0,0,0.2),_0_-8px_24px_rgba(0,0,0,0.15)] p-6 pb-8">
          <div className="flex justify-center mb-6">
            <div className="w-12 h-1.5 bg-[#D1D1D6] rounded-full" />
          </div>

        <h3 className="text-2xl font-bold mb-5" style={{ fontFamily: 'var(--font-display)' }}>
          Выберите тариф
        </h3>

        <div className="space-y-3 mb-6">
          {vehicles.map((vehicle) => (
            <button
              key={vehicle.id}
              onClick={() => setSelectedVehicle(vehicle.id)}
              className={`
                w-full p-5 rounded-[24px] border-2 transition-all relative overflow-hidden
                ${selectedVehicle === vehicle.id
                  ? 'border-[#FFD60A] bg-gradient-to-r from-[#FFD60A]/10 to-transparent shadow-[0_12px_48px_rgba(255,214,10,0.3),_0_6px_24px_rgba(0,0,0,0.1)] scale-[1.02]'
                  : 'border-black/10 hover:border-[#FFD60A]/50 hover:bg-black/[0.02] shadow-[0_4px_16px_rgba(0,0,0,0.05)]'
                }
              `}
            >
              <div className="flex items-center gap-4">
                {/* Vehicle Icon */}
                <div className={`
                  text-4xl transition-transform
                  ${selectedVehicle === vehicle.id ? 'scale-110' : ''}
                `}>
                  {vehicle.icon}
                </div>

                {/* Vehicle Info */}
                <div className="flex-1 text-left">
                  <div className="flex items-center gap-2">
                    <span className="font-bold">{vehicle.name}</span>
                    {vehicle.popular && (
                      <span className="px-2 py-0.5 bg-[#FFD60A] text-[#1C1C1E] text-xs rounded-full">
                        Популярный
                      </span>
                    )}
                  </div>
                  <div className="text-sm text-[#6E6E73]">{vehicle.description}</div>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs text-[#6E6E73]">
                      👥 {vehicle.passengers}
                    </span>
                    <span className="text-xs text-[#6E6E73]">
                      ⏱️ {vehicle.eta}
                    </span>
                  </div>
                </div>

                {/* Price */}
                <div className="text-right">
                  <div className="font-bold text-lg">{vehicle.price.split('-')[0]}</div>
                  <div className="text-xs text-[#6E6E73]">от</div>
                </div>
              </div>
            </button>
          ))}
        </div>

        <Button
          variant="primary"
          size="lg"
          fullWidth
          onClick={() => onConfirm(selectedVehicle)}
          className="!py-5 !text-lg !shadow-[0_12px_48px_rgba(255,214,10,0.5),_0_6px_24px_rgba(0,0,0,0.15)]"
        >
          <span className="font-bold">Заказать {vehicles.find(v => v.id === selectedVehicle)?.name}</span>
        </Button>
        </div>
      </div>

      <style>{`
        @keyframes dash {
          to {
            stroke-dashoffset: -100;
          }
        }
      `}</style>
    </div>
  );
}
