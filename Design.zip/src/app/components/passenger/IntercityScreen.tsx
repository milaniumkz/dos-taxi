import { useState } from 'react';
import { Card } from '../design-system/Card';
import { Button } from '../design-system/Button';
import { Input } from '../design-system/Input';

interface IntercityScreenProps {
  onBack: () => void;
  onConfirm: () => void;
}

export function IntercityScreen({ onBack, onConfirm }: IntercityScreenProps) {
  const [selectedClass, setSelectedClass] = useState('comfort');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');

  const classes = [
    {
      id: 'economy',
      name: 'Эконом',
      description: 'Базовый класс',
      icon: '🚗',
      pricePerKm: 120,
      example: '~15,000₸ (120км)'
    },
    {
      id: 'comfort',
      name: 'Комфорт',
      description: 'Комфортные авто',
      icon: '🚙',
      pricePerKm: 180,
      example: '~22,000₸ (120км)'
    },
    {
      id: 'business',
      name: 'Бизнес',
      description: 'Премиум класс',
      icon: '🚘',
      pricePerKm: 280,
      example: '~34,000₸ (120км)'
    }
  ];

  const popularRoutes = [
    { from: 'Алматы', to: 'Астана', distance: '1200км', duration: '12ч', price: '144,000₸' },
    { from: 'Алматы', to: 'Шымкент', distance: '690км', duration: '7ч', price: '82,800₸' },
    { from: 'Алматы', to: 'Караганда', distance: '650км', duration: '6.5ч', price: '78,000₸' }
  ];

  return (
    <div className="min-h-screen bg-[#F7F7F7] pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#FFD60A] via-[#FFB800] to-[#FFA500] p-6 pb-12">
        <button onClick={onBack} className="mb-6 p-2 hover:bg-black/10 rounded-lg transition-colors">
          <svg className="w-6 h-6 text-[#1C1C1E]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        <h1 className="text-3xl font-bold text-[#1C1C1E] mb-2" style={{ fontFamily: 'var(--font-display)' }}>
          🌍 Межгород
        </h1>
        <p className="text-[#1C1C1E]/70">Поездки между городами</p>
      </div>

      <div className="px-4 -mt-8 space-y-4">
        {/* Route Selection */}
        <Card className="!p-6">
          <h3 className="font-bold mb-4">Маршрут</h3>
          <div className="space-y-4">
            <Input
              label="Откуда"
              placeholder="Город отправления"
              defaultValue=""
              icon={
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                </svg>
              }
            />
            <Input
              label="Куда"
              placeholder="Город назначения"
              defaultValue=""
              icon={
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                </svg>
              }
            />
          </div>
        </Card>

        {/* Date & Time */}
        <Card className="!p-6">
          <h3 className="font-bold mb-4">Дата и время</h3>
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Дата"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
            <Input
              label="Время"
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
            />
          </div>
        </Card>

        {/* Class Selection */}
        <div>
          <h3 className="font-bold mb-3 px-1">Выберите класс</h3>
          <div className="space-y-3">
            {classes.map((cls) => (
              <button
                key={cls.id}
                onClick={() => setSelectedClass(cls.id)}
                className="w-full"
              >
                <Card
                  className={`!p-4 transition-all ${
                    selectedClass === cls.id
                      ? 'ring-2 ring-[#FFD60A] scale-[1.02]'
                      : 'hover:shadow-lg'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`text-4xl transition-transform ${
                      selectedClass === cls.id ? 'scale-110' : ''
                    }`}>
                      {cls.icon}
                    </div>
                    <div className="flex-1 text-left">
                      <div className="font-bold text-lg">{cls.name}</div>
                      <div className="text-sm text-[#6E6E73]">{cls.description}</div>
                      <div className="text-xs text-[#FFD60A] mt-1">
                        {cls.pricePerKm}₸/км
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-[#6E6E73]">Пример:</div>
                      <div className="font-bold">{cls.example}</div>
                    </div>
                  </div>
                </Card>
              </button>
            ))}
          </div>
        </div>

        {/* Popular Routes */}
        <div>
          <h3 className="font-bold mb-3 px-1">Популярные маршруты</h3>
          <div className="space-y-3">
            {popularRoutes.map((route, i) => (
              <Card key={i} className="!p-4 hover:shadow-xl transition-all cursor-pointer">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-bold">
                    {route.from} → {route.to}
                  </div>
                  <div className="text-2xl font-bold text-[#FFD60A]" style={{ fontFamily: 'var(--font-display)' }}>
                    {route.price}
                  </div>
                </div>
                <div className="flex items-center gap-4 text-sm text-[#6E6E73]">
                  <span>📏 {route.distance}</span>
                  <span>⏱️ {route.duration}</span>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Additional Options */}
        <Card className="!p-6">
          <h3 className="font-bold mb-4">Дополнительно</h3>
          <div className="space-y-3">
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" className="w-5 h-5 rounded accent-[#FFD60A]" />
              <div className="flex-1">
                <div className="font-medium">Детское кресло</div>
                <div className="text-sm text-[#6E6E73]">+500₸</div>
              </div>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" className="w-5 h-5 rounded accent-[#FFD60A]" />
              <div className="flex-1">
                <div className="font-medium">Кондиционер</div>
                <div className="text-sm text-[#6E6E73]">Включено</div>
              </div>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" className="w-5 h-5 rounded accent-[#FFD60A]" />
              <div className="flex-1">
                <div className="font-medium">Остановки в пути</div>
                <div className="text-sm text-[#6E6E73]">+200₸ за остановку</div>
              </div>
            </label>
          </div>
        </Card>

        <Button
          variant="primary"
          size="lg"
          fullWidth
          onClick={onConfirm}
          className="!py-4 shadow-xl"
        >
          Найти водителя
        </Button>
      </div>
    </div>
  );
}
